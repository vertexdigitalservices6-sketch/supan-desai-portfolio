# Supan Desai — 3D Multi-Page Portfolio Upgrade

An upgrade of Supan Desai's existing single-page portfolio into a fast, SEO-ready, multi-page React and Three.js web application featuring a global Header-Content-Footer (HCF) shell, interactive 3D hero and exhibition scenes, and complete preservation of the original brand identity, palette, typography, and copy.

## User Review & Critical Decisions

> [!IMPORTANT]
> All visual preservation rules from the original site remain strictly locked while integrating your confirmed 3D and Contact enhancements.

- **Confirmed Decision 1 — Hero 3D Centerpiece**: A futuristic wireframe sphere surrounded by a gentle cyan/blue particle field with subtle mouse parallax behind the preserved hero headline, availability badge, and ₹1,000 pricing callout.
- **Confirmed Decision 2 — 3D Portfolio Exhibition**: An interactive 3D spatial exhibition carousel with smooth damped camera transitions, category filters, and clearly labeled editable demo project placeholders linking to dedicated detail pages.
- **Confirmed Decision 3 — Contact Page**: Preserves the original Email, Phone, Fiverr, and Osdire cards verbatim, paired with an interactive `mailto:` project brief builder directly beneath the cards.
- **Confirmed Preservation Lock**: Retains `#0f172a` / `#020617` slate surfaces, cyan and blue accents, `Inter` typography, the `SD` monogram logo, all six original services, all four Fiverr/Osdire links, all four FAQ items, and exact contact details (`supandesai2@gmail.com`, `+91 9104264039`).

---

## 1. Overview & Core Concept

- **What It Does**: Transforms the standalone HTML portfolio into a 16-route multi-page portfolio experience for **Supan Desai (Full Stack Web Architect & AI Engineer)**, enriched with interactive WebGL 3D scenes, route-level SEO metadata, and 3D depth micro-interactions.
- **Target Audience / Persona**: Startup founders, product managers, and agencies evaluating Supan Desai across Web & Admin Panels, AI Chatbots & GenAI, Unity/C++ Game Development, Digital Marketing & SEO, UI/UX Design, and Mobile App Development.
- **Key Value**: Preserves instant brand familiarity and low-friction direct hiring (Fiverr, Osdire, Email, Phone) while elevating technical credibility through interactive 3D architecture, dedicated service breakdowns, and independently indexable pages.

---

## 2. User Experience & Visual Design

### Visual Identity & Theme (Preserved)
- **Aesthetic Direction**: High-contrast dark engineering showcase with subtle 3D spatial depth—clean, direct, and unmistakably the original Supan Desai site.
- **Color Palette**:
  - Primary Canvas: `#0f172a` (Slate 900) alternating with `#020617` (Slate 950) section bands.
  - Structural Surfaces: `#1e293b` (Slate 800) cards with hairline `#334155` (Slate 700) borders.
  - Primary & Secondary Accents: Cyan (`#06b6d4` / `#22d3ee`) and Blue (`#3b82f6` / `#2563eb`), alongside original service icon accents and marketplace brand highlights (Green for Fiverr, Purple for Osdire).
- **Typography & Hierarchy**: `Inter` across headings and body prose, paired with monospace (`font-mono`) for the `SD` mark, technology tags, and tabular pricing/metrics.

### Key User Flows
1. **Home (`/`)**: Lands on the preserved Hero (availability badge, gradient headline, dual CTAs, ₹1,000 starting badge) layered cleanly in front of the interactive 3D wireframe sphere and particle field; flows through the Technology Marquee, 3D-tilting Core Services preview cards, Verified Gigs & Offers preview, FAQ accordion preview, and Contact CTA.
2. **Global Navigation (HCF Shell)**: Persistent header with the `SD` logo, top-level navigation (`Home`, `About`, `Services` dropdown for all 6 disciplines, `Technology`, `Portfolio`, `Offers`, `FAQ`, `Contact`), `Hire Me` CTA, active route indicator, and responsive mobile drawer; persistent footer with `SD` branding, quick navigation, services links, Fiverr/Osdire links, contact links, and dynamic copyright year.
3. **3D Portfolio Exhibition (`/portfolio` -> `/portfolio/:slug`)**: Users filter editable demo showcases by discipline (`All`, `Web & Admin`, `AI & GenAI`, `Games`, `Mobile Apps`, `UI/UX & SEO`), rotate or click cards in the 3D spatial carousel with damped camera focus, inspect loading states or CSS 3D fallback if WebGL is disabled, and open dedicated project detail routes with architecture summaries and direct hire CTAs.
4. **Technology Stack (`/technology`)**: Interactive 3D orbital node showcase presenting the 13 original technologies grouped by category (`Frontend & UI`, `Backend & Databases`, `AI & Machine Learning`, `Game & Mobile`) with click-to-inspect details and zero fabricated proficiency claims.
5. **Services (`/services` & `/services/:slug`)**: Overview grid with 3D perspective tilt cards linking to six independent service detail pages covering Overview, Features, Technologies, Benefits, Development Workflow, and Marketplace/Contact CTA.
6. **About (`/about`), Offers (`/offers`), FAQ (`/faq`), Contact (`/contact`), & 404 (`/404`)**: Dedicated pages with breadcrumbs, structured data, and interactive controls—including the `mailto:` project brief builder on Contact that composes a pre-filled email to `supandesai2@gmail.com` from selected service, scope, budget, and brief notes.

### Interactive Feedback & Motion
- **3D Card Perspective**: Smooth CSS 3D tilt-on-hover, depth shadows, and cyan border glow on service and offer cards.
- **Page & Section Transitions**: Subtle compositor-only (`transform`, `opacity`) transitions respecting `prefers-reduced-motion`.
- **3D Scene Ergonomics**: Unobstructed 3D viewports with compact bottom control bars for camera/carousel navigation, loading indicators during lazy scene chunk initialization, and automatic CSS 3D fallback when WebGL is unavailable or reduced motion is active.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Direct Three.js Viewport Engine with React Lifecycle Isolation**
  - *Chosen Approach*: Mount Three.js WebGL scenes inside isolated React `useRef` containers with lazy-loaded route/scene chunks, `RoomEnvironment` PBR reflections, `THREE.MathUtils.damp` transitions, software-WebGL detection (`isSoftwareGl`) for frame pacing, and automatic CSS 3D fallback.
  - *Why*: Guarantees rock-solid compatibility with React 19, avoids unnecessary reconciler overhead, prevents UI state changes from resetting WebGL contexts, and ensures smooth performance on both hardware GPUs and mobile/low-power environments.
  - *Alternatives Considered*: Heavy multi-pass post-processing pipelines or React-reconciler-coupled 3D trees, which add bundle weight and risk context loss during route transitions.

- **Decision 2 — Editable Demo Placeholder Architecture for Portfolio Projects**
  - *Chosen Approach*: Define six clearly badged "Editable Demo Placeholder" case studies mapped to Supan Desai's real service domains, stored in a centralized data module with clear placeholder markers.
  - *Why*: Satisfies the strict requirement never to fabricate client metrics, testimonials, or completed client claims while still demonstrating a complete, interactive 3D exhibition and detail-page workflow.
  - *Alternatives Considered*: Empty gallery grids (poor UX) or invented case studies (violates integrity rules).

- **Decision 3 — Client-Side `mailto:` Project Brief Builder on Contact**
  - *Chosen Approach*: Retain the original Email, Phone, Fiverr, and Osdire cards intact and place a lightweight interactive brief builder below them that previews and launches a structured `mailto:supandesai2@gmail.com` draft (plus one-click copy).
  - *Why*: Honors the original "form removed" direct-contact philosophy while giving prospective clients a structured way to specify service type, starting budget, and project summary without backend form dependencies.
  - *Alternatives Considered*: Server-side database form submission (unnecessary friction and infrastructure for a static-friendly portfolio).

---

## 4. Technical Architecture & Data Strategy

### Architecture & Component Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           BrowserRouter & SEO                           │
│   Dynamic <head> Meta · Canonical URL · OG/Twitter · JSON-LD · Fallback │
└───────────────────────────────────┬─────────────────────────────────────┘
                                    │
┌───────────────────────────────────▼─────────────────────────────────────┐
│                         Global HCF Layout Shell                         │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │ HEADER: SD Logo · Nav Links · Services Dropdown · Hire Me CTA     │  │
│  └───────────────────────────────────────────────────────────────────┘  │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │ CONTENT (16 Routes via Suspense + Lazy 3D Chunks):                │  │
│  │  /                 -> Home + Hero 3D Wireframe Sphere & Particles │  │
│  │  /about            -> Profile, Approach, Philosophy               │  │
│  │  /services         -> 6 Tilt Cards -> /services/:slug (6 Pages)   │  │
│  │  /technology       -> 13 Tech Nodes + Interactive 3D Constellation│  │
│  │  /portfolio        -> 3D Spatial Carousel -> /portfolio/:slug     │  │
│  │  /offers           -> 4 Verified Fiverr & Osdire Marketplace Cards│  │
│  │  /faq              -> Expandable Accordion + Trust Pillars        │  │
│  │  /contact          -> Direct Contact Cards + Mailto Brief Builder │  │
│  │  /404 & *          -> Branded Recovery Page                       │  │
│  └───────────────────────────────────────────────────────────────────┘  │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │ FOOTER: SD Branding · Quick Links · Services · Marketplace · Copy │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└───────────────────────────────────┬─────────────────────────────────────┘
                                    │
┌───────────────────────────────────▼─────────────────────────────────────┐
│               Centralized Data & Resilient 3D Services                  │
│  Services · Demo Projects · 13 Technologies · 4 Offers · 4 FAQs · SEO   │
│  WebGL Capability Probe · Software-GL Pacing · CSS 3D Graceful Fallback │
└─────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State
- **Centralized Domain Catalogs**: Typed data modules for the 6 Services (with features, workflow steps, benefits, and technologies), 6 Editable Demo Projects (slug, category, placeholder notice, summary, stack, deliverables), 13 Technologies (categorized without fake ratings), 4 Marketplace Offers (exact Fiverr & Osdire URLs), and 4 FAQs.
- **Route & UI State**: Managed via React Router navigation state, active dropdown/mobile drawer state in the shared Header, accordion state in FAQ, active category filter and focused carousel index in Portfolio 3D, selected tech node in Technology 3D, and form-free brief composer state in Contact.

### Interactive Component & State Mapping
- **Header & Dropdown**: Hover/click toggles the 6-item Services menu, keyboard `Escape` and route changes auto-close both the dropdown and mobile drawer, and active routes highlight in Cyan.
- **3D Scene Wrapper**: Checks `prefers-reduced-motion` and WebGL2/WebGL1 availability on mount; renders a lazy-loaded Three.js canvas with `webglcontextlost` recovery and disposal on unmount, or seamlessly swaps to a visually consistent CSS 3D fallback.
- **3D Portfolio Carousel**: Clicking a category filter updates the visible 3D exhibition ring; clicking Next/Prev, selecting a 3D card via raycasting, or picking from the bottom dock smoothly damps the camera and ring rotation to focus the selected project and updates the inspectable summary card with a direct link to `/portfolio/:slug`.
- **SEO & Indexability**: Every route updates document metadata, canonical links, breadcrumbs, and JSON-LD structured data, complemented by static `sitemap.xml` and `robots.txt` assets.
