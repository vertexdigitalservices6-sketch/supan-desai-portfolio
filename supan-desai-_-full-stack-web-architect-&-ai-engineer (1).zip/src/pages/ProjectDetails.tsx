import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Check, Info, Layers } from 'lucide-react';
import Breadcrumbs from '../components/Breadcrumbs';
import CTA from '../components/CTA';
import NotFound from './NotFound';
import { getProjectBySlug, PROJECTS } from '../data/projects';
import { getServiceBySlug } from '../data/services';
import { useSEO } from '../hooks/useSEO';

export default function ProjectDetails() {
  const { slug } = useParams<{ slug: string }>();
  const project = getProjectBySlug(slug);

  useSEO({
    title: project
      ? `${project.title} | 3D Portfolio — Supan Desai`
      : 'Project Not Found | Supan Desai',
    description: project
      ? `${project.shortDesc} (${project.placeholderNotice}).`
      : 'The requested portfolio blueprint could not be found.',
    path: slug ? `/portfolio/${slug}` : '/portfolio',
    type: 'article',
    structuredData: project
      ? {
          '@context': 'https://schema.org',
          '@type': 'CreativeWork',
          name: project.title,
          description: project.fullOverview,
          creator: {
            '@type': 'Person',
            name: 'Supan Desai',
          },
          keywords: project.technologies.join(', '),
        }
      : undefined,
  });

  if (!project) {
    return <NotFound />;
  }

  const currentIdx = PROJECTS.findIndex((p) => p.slug === project.slug);
  const prevProject =
    PROJECTS[(currentIdx - 1 + PROJECTS.length) % PROJECTS.length];
  const nextProject = PROJECTS[(currentIdx + 1) % PROJECTS.length];
  const relatedService = getServiceBySlug(project.relatedServiceSlug);

  return (
    <div className="pt-28 bg-slate-900">
      <section className="py-12 md:py-16 border-b border-slate-800">
        <div className="container mx-auto px-6">
          <Breadcrumbs
            items={[
              { label: '3D Portfolio', to: '/portfolio' },
              { label: project.title },
            ]}
          />

          {/* Clear Placeholder Banner */}
          <div className="mb-8 p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3 text-sm text-amber-200">
            <Info size={18} className="text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">{project.placeholderNotice}.</span>{' '}
              This blueprint demonstrates architecture, deliverables, and stack
              structure without fabricated client results.
            </div>
          </div>

          <div className="grid lg:grid-cols-12 gap-10 items-start">
            <div className="lg:col-span-8">
              <div className="flex items-center gap-3 text-xs font-mono uppercase tracking-widest text-cyan-400 mb-3">
                <Layers size={16} />
                <span>{project.category}</span>
              </div>
              <h1 className="text-3xl md:text-5xl font-black text-white mb-6 leading-tight">
                {project.title}
              </h1>
              <p className="text-lg text-slate-300 leading-relaxed mb-5">
                {project.shortDesc}
              </p>
              <p className="text-slate-400 leading-relaxed mb-8">
                {project.fullOverview}
              </p>

              <div className="flex flex-wrap gap-4">
                <Link
                  to="/contact"
                  className="px-7 py-3.5 bg-cyan-500 hover:bg-cyan-600 text-white font-bold rounded-lg transition-colors inline-flex items-center gap-2 text-sm"
                >
                  <span>Build Something Similar</span>
                  <ArrowRight size={16} />
                </Link>
                {relatedService && (
                  <Link
                    to={`/services/${relatedService.slug}`}
                    className="px-7 py-3.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-bold rounded-lg transition-colors text-sm"
                  >
                    View {relatedService.navLabel} Service
                  </Link>
                )}
              </div>
            </div>

            {/* Tech & Category Card */}
            <div
              className="lg:col-span-4 rounded-2xl border border-slate-700 p-7"
              style={{
                background: `linear-gradient(145deg, #1e293b 0%, #0f172a 75%, ${project.accentHex}22 100%)`,
              }}
            >
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                Technologies Included
              </div>
              <div className="flex flex-wrap gap-2 mb-6">
                {project.technologies.map((tech) => (
                  <Link
                    key={tech}
                    to="/technology"
                    className="text-xs px-3 py-1.5 bg-slate-900/90 rounded-lg text-slate-200 hover:text-cyan-400 font-mono border border-slate-700 transition-colors"
                  >
                    {tech}
                  </Link>
                ))}
              </div>
              <div className="pt-4 border-t border-slate-700/80 text-xs text-slate-400">
                Status:{' '}
                <span className="text-amber-300 font-semibold">
                  Editable Demo Blueprint
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Architecture Highlights & Deliverables */}
      <section className="py-16 bg-slate-950">
        <div className="container mx-auto px-6 grid md:grid-cols-2 gap-8">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8">
            <h2 className="text-2xl font-bold text-white mb-6">
              Architecture Highlights
            </h2>
            <ul className="space-y-4">
              {project.architectureHighlights.map((item) => (
                <li
                  key={item}
                  className="flex items-start gap-3 text-sm text-slate-300"
                >
                  <span className="p-1 rounded bg-cyan-500/15 text-cyan-400 mt-0.5 shrink-0">
                    <Check size={14} />
                  </span>
                  <span className="leading-relaxed">{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8">
            <h2 className="text-2xl font-bold text-white mb-6">
              Standard Project Deliverables
            </h2>
            <ul className="space-y-4">
              {project.deliverables.map((item) => (
                <li
                  key={item}
                  className="flex items-start gap-3 text-sm text-slate-300"
                >
                  <span className="p-1 rounded bg-green-500/15 text-green-400 mt-0.5 shrink-0">
                    <Check size={14} />
                  </span>
                  <span className="leading-relaxed">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Previous / Next Blueprint Navigation */}
      <section className="py-10 bg-slate-900 border-t border-slate-800">
        <div className="container mx-auto px-6 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
          <Link
            to={`/portfolio/${prevProject.slug}`}
            className="p-4 rounded-xl bg-slate-800/60 border border-slate-700 hover:border-cyan-500/50 transition-colors flex items-center gap-3 group"
          >
            <ArrowLeft
              size={18}
              className="text-slate-400 group-hover:text-cyan-400 shrink-0"
            />
            <div>
              <div className="text-[11px] font-mono text-slate-400 uppercase">
                Previous Blueprint
              </div>
              <div className="text-sm font-bold text-white group-hover:text-cyan-400 transition-colors">
                {prevProject.title}
              </div>
            </div>
          </Link>

          <Link
            to="/portfolio"
            className="text-xs font-bold uppercase tracking-wider text-slate-400 hover:text-cyan-400 text-center py-2"
          >
            Back to 3D Exhibition
          </Link>

          <Link
            to={`/portfolio/${nextProject.slug}`}
            className="p-4 rounded-xl bg-slate-800/60 border border-slate-700 hover:border-cyan-500/50 transition-colors flex items-center justify-end gap-3 text-right group"
          >
            <div>
              <div className="text-[11px] font-mono text-slate-400 uppercase">
                Next Blueprint
              </div>
              <div className="text-sm font-bold text-white group-hover:text-cyan-400 transition-colors">
                {nextProject.title}
              </div>
            </div>
            <ArrowRight
              size={18}
              className="text-slate-400 group-hover:text-cyan-400 shrink-0"
            />
          </Link>
        </div>
      </section>

      <CTA />
    </div>
  );
}
