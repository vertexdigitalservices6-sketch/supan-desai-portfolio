import { Link } from 'react-router-dom';
import { Check, ExternalLink, ShieldCheck } from 'lucide-react';
import Breadcrumbs from '../components/Breadcrumbs';
import CTA from '../components/CTA';
import { OFFERS } from '../data/offers';
import { PROFILE } from '../data/profile';
import { useSEO } from '../hooks/useSEO';

export default function Offers() {
  useSEO({
    title: 'Verified Fiverr & Osdire Offers | Supan Desai',
    description:
      'Hire Supan Desai directly through verified Fiverr gigs and Osdire offers with buyer protection—covering Web & AI Development, Apps & Games, and Advanced SEO Audits.',
    path: '/offers',
  });

  const fiverrOffers = OFFERS.filter((o) => o.platform === 'Fiverr');
  const osdireOffers = OFFERS.filter((o) => o.platform === 'Osdire');

  return (
    <div className="pt-28 bg-slate-900">
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-6">
          <Breadcrumbs items={[{ label: 'Offers' }]} />

          <div className="max-w-3xl mb-12">
            <h1 className="text-4xl md:text-5xl font-black text-white mb-4">
              Verified Gigs &amp;{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
                Marketplace Offers
              </span>
            </h1>
            <p className="text-lg text-slate-400 leading-relaxed mb-5">
              Hire me directly through trusted platforms with escrow buyer
              protection, or reach out directly for custom fixed-price scopes
              starting from <span className="text-white font-semibold">{PROFILE.startingPrice}</span>.
            </p>
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-green-400 bg-slate-800/80 border border-slate-700 px-4 py-2 rounded-lg">
              <ShieldCheck size={16} />
              <span>Official Verified Platform Links — Buyer Protection Included</span>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-6xl">
            {/* Fiverr Column */}
            <div className="space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-green-500 flex items-center justify-center font-bold text-white text-xs">
                    fi
                  </div>
                  <h2 className="text-2xl font-bold text-white">Fiverr Gigs</h2>
                </div>
                <a
                  href={PROFILE.fiverrProfileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-semibold text-green-400 hover:underline inline-flex items-center gap-1"
                >
                  Profile <ExternalLink size={12} />
                </a>
              </div>

              {fiverrOffers.map((offer) => (
                <div
                  key={offer.id}
                  className="p-7 bg-slate-950 rounded-2xl border border-slate-800 hover:border-green-500/70 transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex justify-between items-start gap-4 mb-3">
                      <h3 className="font-bold text-xl text-white">
                        {offer.title}
                      </h3>
                      <span className="text-[11px] font-mono uppercase px-2.5 py-1 rounded bg-green-500/15 text-green-400 border border-green-500/30">
                        Fiverr
                      </span>
                    </div>
                    <p className="text-sm text-slate-400 mb-5 leading-relaxed">
                      {offer.description}
                    </p>
                    <ul className="space-y-2 mb-6">
                      {offer.highlights.map((h) => (
                        <li
                          key={h}
                          className="flex items-center gap-2 text-xs text-slate-300"
                        >
                          <Check size={14} className="text-green-400 shrink-0" />
                          <span>{h}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-800">
                    <Link
                      to={`/services/${offer.relatedServiceSlug}`}
                      className="text-xs font-semibold text-slate-400 hover:text-cyan-400 transition-colors"
                    >
                      View Service Details
                    </Link>
                    <a
                      href={offer.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-4 py-2 rounded-lg bg-green-600 hover:bg-green-500 text-white text-xs font-bold inline-flex items-center gap-1.5 transition-colors"
                    >
                      <span>Open on Fiverr</span>
                      <ExternalLink size={14} />
                    </a>
                  </div>
                </div>
              ))}
            </div>

            {/* Osdire Column */}
            <div className="space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-purple-600 flex items-center justify-center font-bold text-white text-xs">
                    Os
                  </div>
                  <h2 className="text-2xl font-bold text-white">Osdire Offers</h2>
                </div>
                <a
                  href={PROFILE.osdireProfileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-semibold text-purple-400 hover:underline inline-flex items-center gap-1"
                >
                  Profile <ExternalLink size={12} />
                </a>
              </div>

              {osdireOffers.map((offer) => (
                <div
                  key={offer.id}
                  className="p-7 bg-slate-950 rounded-2xl border border-slate-800 hover:border-purple-500/70 transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex justify-between items-start gap-4 mb-3">
                      <h3 className="font-bold text-xl text-white">
                        {offer.title}
                      </h3>
                      <span className="text-[11px] font-mono uppercase px-2.5 py-1 rounded bg-purple-500/15 text-purple-400 border border-purple-500/30">
                        Osdire
                      </span>
                    </div>
                    <p className="text-sm text-slate-400 mb-5 leading-relaxed">
                      {offer.description}
                    </p>
                    <ul className="space-y-2 mb-6">
                      {offer.highlights.map((h) => (
                        <li
                          key={h}
                          className="flex items-center gap-2 text-xs text-slate-300"
                        >
                          <Check size={14} className="text-purple-400 shrink-0" />
                          <span>{h}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-800">
                    <Link
                      to={`/services/${offer.relatedServiceSlug}`}
                      className="text-xs font-semibold text-slate-400 hover:text-cyan-400 transition-colors"
                    >
                      View Service Details
                    </Link>
                    <a
                      href={offer.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-4 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold inline-flex items-center gap-1.5 transition-colors"
                    >
                      <span>Open on Osdire</span>
                      <ExternalLink size={14} />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <CTA />
    </div>
  );
}
