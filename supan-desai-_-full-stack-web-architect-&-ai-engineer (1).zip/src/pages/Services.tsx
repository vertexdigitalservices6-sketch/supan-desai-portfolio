import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import Breadcrumbs from '../components/Breadcrumbs';
import ServiceCard from '../components/ServiceCard';
import CTA from '../components/CTA';
import { SERVICES } from '../data/services';
import { PROFILE } from '../data/profile';
import { useSEO } from '../hooks/useSEO';

export default function Services() {
  useSEO({
    title: 'All Services | Web, AI Chatbots, Games, Apps, UI/UX & SEO — Supan Desai',
    description:
      'Explore all six freelance engineering services by Supan Desai: Web & Admin Panels, AI Chatbots & GenAI, Game Development, Digital Marketing & SEO, UI/UX Design, and App Development.',
    path: '/services',
    structuredData: {
      '@context': 'https://schema.org',
      '@type': 'ItemList',
      name: 'Supan Desai Freelance Services',
      itemListElement: SERVICES.map((s, index) => ({
        '@type': 'ListItem',
        position: index + 1,
        name: s.title,
        description: s.desc,
      })),
    },
  });

  return (
    <div className="pt-28 bg-slate-900">
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-6">
          <Breadcrumbs items={[{ label: 'Services' }]} />

          <div className="max-w-3xl mb-12">
            <h1 className="text-4xl md:text-5xl font-black text-white mb-4">
              Core Engineering &amp;{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
                AI Services
              </span>
            </h1>
            <p className="text-lg text-slate-400 leading-relaxed">
              Everything you need to launch and scale your digital presence—from
              responsive websites and secure admin panels to custom Generative AI
              chatbots and Unity games. Fixed-project packages start at{' '}
              <span className="text-white font-semibold">{PROFILE.startingPrice}</span>.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
            {SERVICES.map((service) => (
              <ServiceCard key={service.slug} service={service} />
            ))}
          </div>

          {/* Engagement Guarantees */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-8 grid md:grid-cols-3 gap-6">
            <div className="flex items-start gap-3">
              <CheckCircle2 size={20} className="text-cyan-400 shrink-0 mt-0.5" />
              <div>
                <h2 className="font-bold text-white text-sm mb-1">
                  Fixed Upfront Quotes
                </h2>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Clear scope and milestone pricing starting from {PROFILE.startingPrice} with no hidden fees.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle2 size={20} className="text-green-400 shrink-0 mt-0.5" />
              <div>
                <h2 className="font-bold text-white text-sm mb-1">
                  100% Source Code Ownership
                </h2>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Full intellectual property and clean repository handover upon final payment.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle2 size={20} className="text-blue-400 shrink-0 mt-0.5" />
              <div>
                <h2 className="font-bold text-white text-sm mb-1">
                  7 Days Free Launch Support
                </h2>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Deployment help on Vercel, Netlify, AWS, DigitalOcean, or Google Play Store.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-10 text-center">
            <Link
              to="/offers"
              className="inline-flex items-center gap-2 text-sm font-semibold text-cyan-400 hover:text-cyan-300 transition-colors"
            >
              <span>Prefer Marketplace Buyer Protection? View Fiverr &amp; Osdire Offers</span>
              <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      <CTA />
    </div>
  );
}
