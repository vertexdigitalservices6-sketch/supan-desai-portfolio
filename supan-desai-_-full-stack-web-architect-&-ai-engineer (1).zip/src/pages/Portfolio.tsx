import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Info } from 'lucide-react';
import Breadcrumbs from '../components/Breadcrumbs';
import Portfolio3D from '../components/Portfolio3D';
import ProjectCard from '../components/ProjectCard';
import CTA from '../components/CTA';
import {
  PORTFOLIO_CATEGORIES,
  PROJECTS,
  type PortfolioCategory,
} from '../data/projects';
import { useSEO } from '../hooks/useSEO';

export default function Portfolio() {
  const navigate = useNavigate();
  const [activeCategory, setActiveCategory] = useState<PortfolioCategory>('All');
  const [selectedIndex, setSelectedIndex] = useState(0);

  useSEO({
    title: '3D Portfolio Exhibition | Supan Desai — Web, AI & Game Demos',
    description:
      'Explore Supan Desai’s interactive 3D portfolio exhibition showcasing editable demo architecture blueprints across Web, AI Chatbots, Unity Games, UI/UX, SEO, and Mobile Apps.',
    path: '/portfolio',
    structuredData: {
      '@context': 'https://schema.org',
      '@type': 'CollectionPage',
      name: 'Supan Desai 3D Portfolio Exhibition',
      description:
        'Interactive 3D spatial exhibition of editable demo project blueprints.',
    },
  });

  const filteredProjects = useMemo(() => {
    if (activeCategory === 'All') return PROJECTS;
    return PROJECTS.filter((p) => p.category === activeCategory);
  }, [activeCategory]);

  const safeIndex =
    selectedIndex >= filteredProjects.length ? 0 : selectedIndex;

  const handleCategoryChange = (cat: PortfolioCategory) => {
    setActiveCategory(cat);
    setSelectedIndex(0);
  };

  return (
    <div className="pt-28 bg-slate-900">
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-6">
          <Breadcrumbs items={[{ label: '3D Portfolio' }]} />

          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-8">
            <div className="max-w-3xl">
              <h1 className="text-4xl md:text-5xl font-black text-white mb-4">
                Interactive{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
                  3D Portfolio
                </span>
              </h1>
              <p className="text-lg text-slate-400 leading-relaxed">
                Navigate the 3D spatial exhibition carousel to inspect project
                architecture blueprints across Web, Generative AI, Games, UI/UX,
                SEO, and Mobile App development.
              </p>
            </div>
          </div>

          {/* Transparent Editable Demo Notice */}
          <div className="mb-8 p-4 rounded-xl bg-slate-800/70 border border-slate-700 flex items-start gap-3 text-sm text-slate-300">
            <Info size={18} className="text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-white">
                Editable Demo Placeholders:
              </span>{' '}
              To avoid fabricated client claims or fake results, these exhibition
              stands present clearly labeled demonstration blueprints ready to be
              swapped with your live case studies.
            </div>
          </div>

          {/* Category Filters */}
          <div
            className="flex flex-wrap gap-2 mb-8"
            role="tablist"
            aria-label="Filter portfolio projects by category"
          >
            {PORTFOLIO_CATEGORIES.map((category) => (
              <button
                key={category}
                type="button"
                onClick={() => handleCategoryChange(category)}
                className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors ${
                  activeCategory === category
                    ? 'bg-cyan-500 text-white shadow-md shadow-cyan-500/20'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* 3D Spatial Exhibition Carousel */}
          <div className="mb-14">
            <Portfolio3D
              projects={filteredProjects}
              selectedIndex={safeIndex}
              onSelectIndex={setSelectedIndex}
              onInspectProject={(slug) => navigate(`/portfolio/${slug}`)}
            />
          </div>

          {/* Synchronized Project Blueprint Cards */}
          <div className="mb-6 flex items-center justify-between">
            <h2 className="text-2xl font-bold text-white">
              Exhibition Blueprints ({filteredProjects.length})
            </h2>
            <span className="text-xs font-mono text-slate-400">
              Select any card for full architecture details
            </span>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map((project, idx) => (
              <ProjectCard
                key={project.slug}
                project={project}
                isFocused={idx === safeIndex}
              />
            ))}
          </div>
        </div>
      </section>

      <CTA />
    </div>
  );
}
