import { useMemo, useState } from 'react';
import { Check, Copy, ExternalLink, Mail, Phone, Send } from 'lucide-react';
import Breadcrumbs from '../components/Breadcrumbs';
import { PROFILE } from '../data/profile';
import { SERVICES } from '../data/services';
import { useSEO } from '../hooks/useSEO';

const SCOPE_TIERS = [
  'Starter Task (From ₹1,000)',
  'Standard Project Build',
  'Full-Stack + AI / Custom Scope',
] as const;

export default function Contact() {
  useSEO({
    title: 'Contact Supan Desai | Hire Full Stack Web Architect & AI Engineer',
    description: `Contact Supan Desai at ${PROFILE.email} or ${PROFILE.phoneDisplay}. Based in India, serving global clients via direct hire, Fiverr, and Osdire.`,
    path: '/contact',
  });

  const [selectedService, setSelectedService] = useState(SERVICES[0].navLabel);
  const [scopeTier, setScopeTier] = useState<string>(SCOPE_TIERS[0]);
  const [clientName, setClientName] = useState('');
  const [projectNotes, setProjectNotes] = useState('');
  const [copied, setCopied] = useState(false);

  const briefText = useMemo(() => {
    const sender = clientName.trim() ? clientName.trim() : 'Prospective Client';
    const notes = projectNotes.trim()
      ? projectNotes.trim()
      : 'Please share your project requirements, timeline, and target platform.';
    return [
      `Hi Supan,`,
      ``,
      `I would like to discuss a project inquiry:`,
      `- Name / Brand: ${sender}`,
      `- Service Needed: ${selectedService}`,
      `- Budget / Scope Tier: ${scopeTier}`,
      ``,
      `Project Summary:`,
      `${notes}`,
    ].join('\n');
  }, [clientName, selectedService, scopeTier, projectNotes]);

  const mailtoUrl = useMemo(() => {
    const subject = encodeURIComponent(
      `Project Inquiry: ${selectedService} (${scopeTier})`
    );
    const body = encodeURIComponent(briefText);
    return `mailto:${PROFILE.email}?subject=${subject}&body=${body}`;
  }, [selectedService, scopeTier, briefText]);

  const handleCopyBrief = async () => {
    try {
      await navigator.clipboard.writeText(briefText);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="pt-28 pb-20 bg-slate-950">
      <div className="container mx-auto px-6">
        <Breadcrumbs items={[{ label: 'Contact' }]} />

        {/* Preserved Original Contact Card */}
        <div className="max-w-3xl mx-auto bg-slate-800 border border-slate-700 rounded-3xl overflow-hidden shadow-2xl p-8 md:p-12 text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-2 text-white">
            Get In Touch
          </h1>
          <p className="text-slate-400 mb-10 text-sm">
            {PROFILE.locationSummary}
          </p>

          <div className="grid md:grid-cols-2 gap-6 mb-10">
            {/* Email Card */}
            <a
              href={PROFILE.emailHref}
              className="flex flex-col items-center p-6 bg-slate-900 rounded-2xl border border-slate-700 hover:border-cyan-500/50 group transition-all"
            >
              <div className="w-12 h-12 rounded-xl bg-slate-800 group-hover:bg-cyan-500/20 flex items-center justify-center transition-colors mb-4">
                <Mail
                  size={24}
                  className="text-slate-300 group-hover:text-cyan-400"
                />
              </div>
              <span className="text-xs text-slate-500 uppercase font-bold tracking-wider mb-1">
                Email Me
              </span>
              <span className="font-medium text-white group-hover:text-cyan-400 transition-colors">
                {PROFILE.email}
              </span>
            </a>

            {/* Phone Card */}
            <a
              href={PROFILE.phoneHref}
              className="flex flex-col items-center p-6 bg-slate-900 rounded-2xl border border-slate-700 hover:border-green-500/50 group transition-all"
            >
              <div className="w-12 h-12 rounded-xl bg-slate-800 group-hover:bg-green-500/20 flex items-center justify-center transition-colors mb-4">
                <Phone
                  size={24}
                  className="text-slate-300 group-hover:text-green-400"
                />
              </div>
              <span className="text-xs text-slate-500 uppercase font-bold tracking-wider mb-1">
                Call Me
              </span>
              <span className="font-medium text-white group-hover:text-green-400 transition-colors">
                {PROFILE.phoneDisplay}
              </span>
            </a>
          </div>

          <div className="pt-8 border-t border-slate-700">
            <p className="text-xs text-slate-500 mb-4">
              You can also find me on:
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <a
                href={PROFILE.fiverrProfileUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-2 bg-slate-900 rounded-full border border-slate-700 text-sm font-bold text-slate-300 hover:border-green-500 hover:text-green-500 transition-colors inline-flex items-center gap-1.5"
              >
                <span>Fiverr</span>
                <ExternalLink size={14} />
              </a>
              <a
                href={PROFILE.osdireProfileUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-2 bg-slate-900 rounded-full border border-slate-700 text-sm font-bold text-slate-300 hover:border-purple-500 hover:text-purple-500 transition-colors inline-flex items-center gap-1.5"
              >
                <span>Osdire</span>
                <ExternalLink size={14} />
              </a>
            </div>
          </div>
        </div>

        {/* Mailto Project Brief Builder */}
        <div className="max-w-3xl mx-auto bg-slate-900 border border-slate-800 rounded-3xl p-8 md:p-10 shadow-xl">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-white mb-2">
              Project Brief Builder
            </h2>
            <p className="text-sm text-slate-400">
              Compose a structured inquiry and launch it directly in your email
              app addressed to{' '}
              <span className="text-cyan-400 font-mono">{PROFILE.email}</span>.
            </p>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                1. Select Service
              </label>
              <div className="flex flex-wrap gap-2">
                {SERVICES.map((service) => (
                  <button
                    key={service.slug}
                    type="button"
                    onClick={() => setSelectedService(service.navLabel)}
                    className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors ${
                      selectedService === service.navLabel
                        ? 'bg-cyan-500 text-white'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
                    }`}
                  >
                    {service.navLabel}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-5">
              <div>
                <label
                  htmlFor="brief-scope"
                  className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2"
                >
                  2. Scope Tier
                </label>
                <select
                  id="brief-scope"
                  value={scopeTier}
                  onChange={(e) => setScopeTier(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-cyan-500"
                >
                  {SCOPE_TIERS.map((tier) => (
                    <option key={tier} value={tier}>
                      {tier}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="brief-name"
                  className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2"
                >
                  3. Your Name or Company (Optional)
                </label>
                <input
                  id="brief-name"
                  type="text"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="e.g. Acme Studio"
                  className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="brief-notes"
                className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2"
              >
                4. Project Goals &amp; Timeline
              </label>
              <textarea
                id="brief-notes"
                rows={4}
                value={projectNotes}
                onChange={(e) => setProjectNotes(e.target.value)}
                placeholder="Briefly describe what you want built, key features, or target launch date..."
                className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>

            {/* Live Formatted Preview */}
            <div className="rounded-xl bg-slate-950 border border-slate-800 p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400">
                  Email Preview
                </span>
                <button
                  type="button"
                  onClick={handleCopyBrief}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-cyan-400 hover:text-cyan-300 transition-colors"
                >
                  {copied ? (
                    <>
                      <Check size={14} className="text-green-400" />
                      <span className="text-green-400">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy size={14} />
                      <span>Copy Brief</span>
                    </>
                  )}
                </button>
              </div>
              <pre className="text-xs font-mono text-slate-300 whitespace-pre-wrap leading-relaxed">
                {briefText}
              </pre>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <a
                href={mailtoUrl}
                className="flex-1 px-6 py-3.5 bg-cyan-500 hover:bg-cyan-600 text-white font-bold rounded-xl transition-colors inline-flex items-center justify-center gap-2 text-sm shadow-lg shadow-cyan-500/20"
              >
                <Send size={16} />
                <span>Open in Email App</span>
              </a>
              <button
                type="button"
                onClick={() => {
                  setClientName('');
                  setProjectNotes('');
                  setSelectedService(SERVICES[0].navLabel);
                  setScopeTier(SCOPE_TIERS[0]);
                }}
                className="px-6 py-3.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold rounded-xl transition-colors text-sm"
              >
                Reset Brief
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
