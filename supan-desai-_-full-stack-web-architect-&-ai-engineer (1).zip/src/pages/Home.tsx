import { Link } from 'react-router-dom';
import {
  ArrowRight,
  Clock,
  ExternalLink,
  Mail,
  Phone,
  Shield,
  Terminal,
  Zap,
} from 'lucide-react';
import Hero3D from '../components/Hero3D';
import ServiceCard from '../components/ServiceCard';
import FAQAccordion from '../components/FAQAccordion';
import { PROFILE } from '../data/profile';
import { SERVICES } from '../data/services';
import { TECH_STACK_MARQUEE } from '../data/technologies';
import { OFFERS } from '../data/offers';
import { FAQS } from '../data/faqs';
import { useSEO } from '../hooks/useSEO';

export default function Home() {
  useSEO({
    title: 'Supan Desai | Freelance Full Stack Web Architect & AI Engineer',
    description:
      'Hire Supan Desai for high-performance Web Development, AI Chatbots, Game Dev, and UI/UX. Scalable solutions for startups & global brands. Starting at ₹1,000.',
    path: '/',
    structuredData: [
      {
        '@context': 'https://schema.org',
        '@type': 'Person',
        name: PROFILE.name,
        jobTitle: PROFILE.fullTitle,
        email: PROFILE.email,
        telephone: PROFILE.phoneDisplay,
        url: typeof window !== 'undefined' ? window.location.origin : '',
        sameAs: [PROFILE.fiverrProfileUrl, PROFILE.osdireProfileUrl],
      },
      {
        '@context': 'https://schema.org',
        '@type': 'ProfessionalService',
        name: `${PROFILE.name} — ${PROFILE.fullTitle}`,
        priceRange: `Starting from ${PROFILE.startingPrice}`,
        areaServed: 'Worldwide',
        telephone: PROFILE.phoneDisplay,
        email: PROFILE.email,
      },
    ],
  });

  const fiverrOffers = OFFERS.filter((o) => o.platform === 'Fiverr');
  const osdireOffers = OFFERS.filter((o) => o.platform === 'Osdire');

  return (
    <>
      {/* Hero Section with 3D Wireframe Sphere & Particles */}
      <section
        id="home"
        className="relative pt-32 pb-20 md:pt-44 md:pb-28 overflow-hidden flex items-center min-h-[92vh] bg-slate-900"
      >
        {/* Background Decorative Blurs */}
        <div
          className="absolute top-0 right-0 w-1/2 h-full bg-cyan-500/5 blur-[120px] rounded-full pointer-events-none"
          aria-hidden="true"
        />
        <div
          className="absolute bottom-0 left-0 w-1/3 h-full bg-purple-500/5 blur-[120px] rounded-full pointer-events-none"
          aria-hidden="true"
        />

        {/* Lazy-loaded 3D Wireframe Sphere & Particles */}
        <Hero3D />

        {/* Subtle radial scrim to ensure crisp headline contrast */}
        <div
          className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(15,23,42,0.58)_0%,rgba(15,23,42,0.18)_62%,transparent_100%)] pointer-events-none z-[1]"
          aria-hidden="true"
        />

        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-5xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 mb-8 rounded-full bg-slate-800/85 border border-slate-700 text-cyan-400 text-xs font-bold tracking-widest uppercase animate-fade-in-up">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              {PROFILE.availabilityLabel}
            </div>

            <h1 className="text-5xl md:text-7xl lg:text-8xl font-black mb-8 leading-tight tracking-tight text-white">
              BUILDING{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
                INTELLIGENT
              </span>
              <br />
              DIGITAL SOLUTIONS
            </h1>

            <p className="text-lg md:text-xl text-slate-300 mb-12 max-w-2xl mx-auto leading-relaxed">
              Expert Freelance Web Architect &amp; AI Engineer.{' '}
              <br className="hidden md:block" />
              Specializing in <span className="text-cyan-400 font-medium">React</span>,{' '}
              <span className="text-cyan-400 font-medium">Game Dev</span>, and{' '}
              <span className="text-cyan-400 font-medium">Generative AI</span>.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-5 mb-14">
              <Link
                to="/offers"
                className="w-full sm:w-auto px-8 py-4 bg-cyan-500 hover:bg-cyan-600 text-white text-lg font-bold rounded-lg transition-all shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2 group"
              >
                <span>View Gigs &amp; Offers</span>
                <ArrowRight
                  size={20}
                  className="group-hover:translate-x-1 transition-transform"
                />
              </Link>
              <a
                href={PROFILE.phoneHref}
                className="w-full sm:w-auto px-8 py-4 bg-slate-800/90 hover:bg-slate-700 border border-slate-700 text-white text-lg font-bold rounded-lg transition-all flex items-center justify-center gap-2"
              >
                <Phone size={18} />
                <span>{PROFILE.phoneDisplay}</span>
              </a>
            </div>

            {/* Price Badge */}
            <div className="inline-block relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-lg blur opacity-40 group-hover:opacity-75 transition duration-1000" />
              <div className="relative px-8 py-4 bg-slate-900 ring-1 ring-slate-700 rounded-lg leading-none flex items-center space-x-4">
                <span className="text-slate-400 text-sm font-semibold uppercase tracking-wider">
                  Services Starting From
                </span>
                <span className="text-2xl md:text-3xl font-bold text-white tabular-nums">
                  {PROFILE.startingPrice}
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Tech Stack Marquee */}
      <section className="py-8 bg-slate-950 border-y border-slate-800 overflow-hidden">
        <div className="container mx-auto px-6 mb-4 flex items-center justify-center gap-4">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">
            Powering Solutions With
          </span>
          <Link
            to="/technology"
            className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            Explore 3D Tech Stack →
          </Link>
        </div>
        <div className="flex relative overflow-hidden group">
          <div className="flex space-x-12 animate-scroll whitespace-nowrap">
            {[...TECH_STACK_MARQUEE, ...TECH_STACK_MARQUEE, ...TECH_STACK_MARQUEE].map(
              (tech, i) => (
                <span
                  key={`${tech}-${i}`}
                  className="text-xl md:text-2xl font-bold text-slate-600 hover:text-cyan-400 transition-colors cursor-default"
                >
                  {tech}
                </span>
              )
            )}
          </div>
        </div>
      </section>

      {/* Services Preview Grid */}
      <section id="services" className="py-20 bg-slate-900 relative">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12 border-b border-slate-800 pb-8 gap-6">
            <div>
              <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">
                Core Services
              </h2>
              <p className="text-slate-400 max-w-xl">
                Everything you need to launch and scale your digital presence, from
                simple websites to complex AI algorithms.
              </p>
            </div>
            <div className="flex items-center gap-4">
              <Link
                to="/portfolio"
                className="px-4 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-bold uppercase tracking-wider text-cyan-400 transition-colors"
              >
                3D Portfolio Exhibition
              </Link>
              <Link
                to="/services"
                className="px-4 py-2.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-xs font-bold uppercase tracking-wider text-cyan-300 transition-colors"
              >
                All Services
              </Link>
              <Terminal
                size={42}
                className="hidden md:block text-slate-700 opacity-50"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {SERVICES.map((service) => (
              <ServiceCard key={service.slug} service={service} />
            ))}
          </div>
        </div>
      </section>

      {/* Verified Gigs & Offers Preview */}
      <section id="offers" className="py-20 bg-slate-950">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
              Verified Gigs &amp; Marketplace Offers
            </h2>
            <p className="text-slate-400 mb-4">
              Hire me directly through trusted platforms with buyer protection.
            </p>
            <Link
              to="/offers"
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-cyan-400 hover:text-cyan-300 transition-colors"
            >
              <span>Compare All Marketplace Offers</span>
              <ArrowRight size={16} />
            </Link>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {/* Fiverr Column */}
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center font-bold text-white text-xs">
                  fi
                </div>
                <h3 className="text-2xl font-bold text-white">Fiverr Gigs</h3>
              </div>

              {fiverrOffers.map((offer) => (
                <a
                  key={offer.id}
                  href={offer.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block p-6 bg-slate-900 rounded-xl border border-slate-800 hover:border-green-500 transition-all group"
                >
                  <div className="flex justify-between items-start gap-4">
                    <div>
                      <h4 className="font-bold text-lg text-white group-hover:text-green-500 transition-colors mb-2">
                        {offer.title}
                      </h4>
                      <p className="text-sm text-slate-400">{offer.description}</p>
                    </div>
                    <ExternalLink
                      size={18}
                      className="text-slate-600 group-hover:text-green-500 shrink-0"
                    />
                  </div>
                </a>
              ))}
            </div>

            {/* Osdire Column */}
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center font-bold text-white text-xs">
                  Os
                </div>
                <h3 className="text-2xl font-bold text-white">Osdire Offers</h3>
              </div>

              {osdireOffers.map((offer) => (
                <a
                  key={offer.id}
                  href={offer.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block p-6 bg-slate-900 rounded-xl border border-slate-800 hover:border-purple-500 transition-all group"
                >
                  <div className="flex justify-between items-start gap-4">
                    <div>
                      <h4 className="font-bold text-lg text-white group-hover:text-purple-500 transition-colors mb-2">
                        {offer.title}
                      </h4>
                      <p className="text-sm text-slate-400">{offer.description}</p>
                    </div>
                    <ExternalLink
                      size={18}
                      className="text-slate-600 group-hover:text-purple-500 shrink-0"
                    />
                  </div>
                </a>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Preview Section */}
      <section id="faq" className="py-20 bg-slate-900 border-t border-slate-800">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row gap-12">
            <div className="md:w-1/3">
              <h2 className="text-3xl font-bold mb-4 text-white">Common Questions</h2>
              <p className="text-slate-400 mb-6">
                Answers to common questions about my freelance process, payment,
                and delivery.
              </p>
              <div className="flex flex-col gap-4 mb-6">
                <div className="flex items-center gap-3 text-sm text-slate-300">
                  <Shield className="text-green-500 shrink-0" size={20} />
                  <span>100% IP Ownership</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-slate-300">
                  <Clock className="text-cyan-500 shrink-0" size={20} />
                  <span>Fast Turnaround</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-slate-300">
                  <Zap className="text-yellow-500 shrink-0" size={20} />
                  <span>Modern Tech Stack</span>
                </div>
              </div>
              <Link
                to="/faq"
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-cyan-400 hover:text-cyan-300 transition-colors"
              >
                <span>Open Full FAQ Page</span>
                <ArrowRight size={16} />
              </Link>
            </div>
            <div className="md:w-2/3">
              <FAQAccordion items={FAQS} />
            </div>
          </div>
        </div>
      </section>

      {/* Contact CTA Section (Preserving Original Contact Cards) */}
      <section id="contact" className="py-20 bg-slate-950 relative">
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-3xl mx-auto bg-slate-800 border border-slate-700 rounded-3xl overflow-hidden shadow-2xl p-8 md:p-12 text-center">
            <h2 className="text-3xl font-bold mb-2 text-white">Get In Touch</h2>
            <p className="text-slate-400 mb-10 text-sm">{PROFILE.locationSummary}</p>

            <div className="grid md:grid-cols-2 gap-6 mb-10">
              <a
                href={PROFILE.emailHref}
                className="flex flex-col items-center p-6 bg-slate-900 rounded-2xl border border-slate-700 hover:border-cyan-500/50 group transition-all"
              >
                <div className="w-12 h-12 rounded-xl bg-slate-800 group-hover:bg-cyan-500/20 flex items-center justify-center transition-colors mb-4">
                  <Mail
                    size={24}
                    className="text-slate-300 group-hover:text-cyan-400"
                  />
                </div>
                <span className="text-xs text-slate-500 uppercase font-bold tracking-wider mb-1">
                  Email Me
                </span>
                <span className="font-medium text-white group-hover:text-cyan-400 transition-colors">
                  {PROFILE.email}
                </span>
              </a>

              <a
                href={PROFILE.phoneHref}
                className="flex flex-col items-center p-6 bg-slate-900 rounded-2xl border border-slate-700 hover:border-green-500/50 group transition-all"
              >
                <div className="w-12 h-12 rounded-xl bg-slate-800 group-hover:bg-green-500/20 flex items-center justify-center transition-colors mb-4">
                  <Phone
                    size={24}
                    className="text-slate-300 group-hover:text-green-400"
                  />
                </div>
                <span className="text-xs text-slate-500 uppercase font-bold tracking-wider mb-1">
                  Call Me
                </span>
                <span className="font-medium text-white group-hover:text-green-400 transition-colors">
                  {PROFILE.phoneDisplay}
                </span>
              </a>
            </div>

            <div className="pt-8 border-t border-slate-700">
              <p className="text-xs text-slate-500 mb-4">You can also find me on:</p>
              <div className="flex flex-wrap justify-center gap-4 mb-6">
                <a
                  href={PROFILE.fiverrProfileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-2 bg-slate-900 rounded-full border border-slate-700 text-sm font-bold text-slate-300 hover:border-green-500 hover:text-green-500 transition-colors"
                >
                  Fiverr
                </a>
                <a
                  href={PROFILE.osdireProfileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-2 bg-slate-900 rounded-full border border-slate-700 text-sm font-bold text-slate-300 hover:border-purple-500 hover:text-purple-500 transition-colors"
                >
                  Osdire
                </a>
              </div>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-cyan-400 hover:text-cyan-300 transition-colors"
              >
                <span>Open Contact &amp; Project Brief Builder</span>
                <ArrowRight size={14} />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
