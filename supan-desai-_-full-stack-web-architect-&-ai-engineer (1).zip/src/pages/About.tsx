import { Link } from 'react-router-dom';
import { ArrowRight, Code2, Cpu, Layers, ShieldCheck } from 'lucide-react';
import Breadcrumbs from '../components/Breadcrumbs';
import CTA from '../components/CTA';
import { PROFILE } from '../data/profile';
import { TECH_STACK_MARQUEE } from '../data/technologies';
import { useSEO } from '../hooks/useSEO';

const APPROACH_PILLARS = [
  {
    icon: Code2,
    title: 'Architecture Before Code',
    desc: 'Every build begins with clear data structures, clean component boundaries, and predictable REST or AI integration flows.',
  },
  {
    icon: ShieldCheck,
    title: '100% IP & Source Ownership',
    desc: 'Upon final delivery, clients receive full ownership of the codebase, repositories, and deployment configuration.',
  },
  {
    icon: Cpu,
    title: 'Practical AI & Automation',
    desc: 'Generative AI and LLM integrations are designed to solve real operational bottlenecks rather than adding unnecessary complexity.',
  },
  {
    icon: Layers,
    title: 'Build & Launch End-to-End',
    desc: 'From React interfaces on Vercel/Netlify and Admin Panels on AWS/DigitalOcean to Android Play Store releases and 7-day post-launch support.',
  },
];

export default function About() {
  useSEO({
    title: 'About Supan Desai | Full Stack Web Architect & AI Engineer',
    description:
      'Learn about Supan Desai, a freelance Full Stack Web Architect & AI Engineer based in India serving global clients across React, AI Chatbots, Games, Apps, UI/UX, and SEO.',
    path: '/about',
    type: 'profile',
    structuredData: {
      '@context': 'https://schema.org',
      '@type': 'ProfilePage',
      mainEntity: {
        '@type': 'Person',
        name: PROFILE.name,
        jobTitle: PROFILE.fullTitle,
        email: PROFILE.email,
        telephone: PROFILE.phoneDisplay,
      },
    },
  });

  return (
    <div className="pt-28 bg-slate-900">
      {/* Intro Hero */}
      <section className="py-12 md:py-16 border-b border-slate-800">
        <div className="container mx-auto px-6">
          <Breadcrumbs items={[{ label: 'About Me' }]} />

          <div className="grid lg:grid-cols-12 gap-10 items-start">
            <div className="lg:col-span-7">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-800 border border-slate-700 text-cyan-400 text-xs font-bold uppercase tracking-wider mb-5">
                {PROFILE.availabilityLabel}
              </div>
              <h1 className="text-4xl md:text-5xl font-black text-white leading-tight mb-6">
                About{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
                  {PROFILE.name}
                </span>
              </h1>
              <p className="text-lg text-slate-300 leading-relaxed mb-5">
                I am a freelance{' '}
                <span className="text-cyan-400 font-semibold">
                  {PROFILE.fullTitle}
                </span>{' '}
                based in India, serving startups, founders, and businesses
                worldwide.
              </p>
              <p className="text-slate-400 leading-relaxed mb-8">
                My focus is building scalable, high-performance digital products
                that combine modern web engineering, Generative AI automation,
                and clean user experience—with transparent fixed-project pricing
                starting from {PROFILE.startingPrice}.
              </p>

              <div className="flex flex-wrap gap-4">
                <Link
                  to="/portfolio"
                  className="px-6 py-3 bg-cyan-500 hover:bg-cyan-600 text-white font-bold rounded-lg transition-colors inline-flex items-center gap-2 text-sm"
                >
                  <span>Explore 3D Portfolio</span>
                  <ArrowRight size={16} />
                </Link>
                <Link
                  to="/services"
                  className="px-6 py-3 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-bold rounded-lg transition-colors text-sm"
                >
                  Browse All Services
                </Link>
              </div>
            </div>

            {/* Profile Card */}
            <div className="lg:col-span-5">
              <div className="bg-slate-800/60 border border-slate-700 rounded-2xl p-8 shadow-xl">
                <div className="flex items-center gap-4 pb-6 mb-6 border-b border-slate-700">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center font-mono font-bold text-2xl text-white shadow-lg shadow-cyan-500/20">
                    {PROFILE.brandInitials}
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-white">{PROFILE.name}</h2>
                    <p className="text-sm text-cyan-400 font-mono">
                      {PROFILE.fullTitle}
                    </p>
                  </div>
                </div>

                <dl className="space-y-4 text-sm">
                  <div className="flex justify-between gap-4 border-b border-slate-700/60 pb-3">
                    <dt className="text-slate-400">Location &amp; Reach</dt>
                    <dd className="text-white font-medium text-right">
                      {PROFILE.locationSummary}
                    </dd>
                  </div>
                  <div className="flex justify-between gap-4 border-b border-slate-700/60 pb-3">
                    <dt className="text-slate-400">Starting Rate</dt>
                    <dd className="text-white font-bold font-mono tabular-nums">
                      From {PROFILE.startingPrice}
                    </dd>
                  </div>
                  <div className="flex justify-between gap-4 border-b border-slate-700/60 pb-3">
                    <dt className="text-slate-400">Core Focus</dt>
                    <dd className="text-slate-200 text-right">
                      Web, AI, Games, Mobile, UI/UX, SEO
                    </dd>
                  </div>
                  <div className="flex justify-between gap-4">
                    <dt className="text-slate-400">Post-Launch Support</dt>
                    <dd className="text-green-400 font-medium text-right">
                      7 Days Free Bug-Fix Support
                    </dd>
                  </div>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Development Approach & Philosophy */}
      <section className="py-16 bg-slate-950">
        <div className="container mx-auto px-6">
          <div className="max-w-2xl mb-12">
            <h2 className="text-3xl font-bold text-white mb-3">
              Development Approach &amp; Philosophy
            </h2>
            <p className="text-slate-400">
              Clear communication, predictable pricing, and clean technical
              execution from discovery to deployment.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {APPROACH_PILLARS.map((pillar) => {
              const Icon = pillar.icon;
              return (
                <div
                  key={pillar.title}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-7 hover:border-cyan-500/40 transition-colors"
                >
                  <div className="w-11 h-11 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center mb-4 text-cyan-400">
                    <Icon size={22} />
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2">
                    {pillar.title}
                  </h3>
                  <p className="text-sm text-slate-400 leading-relaxed">
                    {pillar.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Skills & Technology Overview */}
      <section className="py-16 bg-slate-900 border-t border-slate-800">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">
                Technical Interests &amp; Stack
              </h2>
              <p className="text-slate-400">
                Technologies used across web platforms, AI assistants, mobile apps,
                and interactive 2D/3D games.
              </p>
            </div>
            <Link
              to="/technology"
              className="text-sm font-semibold text-cyan-400 hover:text-cyan-300 inline-flex items-center gap-1.5"
            >
              <span>Inspect Interactive 3D Tech Stack</span>
              <ArrowRight size={16} />
            </Link>
          </div>

          <div className="flex flex-wrap gap-3">
            {TECH_STACK_MARQUEE.map((tech) => (
              <Link
                key={tech}
                to="/technology"
                className="px-4 py-2.5 rounded-xl bg-slate-800/70 border border-slate-700 hover:border-cyan-500/60 text-sm font-mono text-slate-200 hover:text-cyan-400 transition-colors"
              >
                {tech}
              </Link>
            ))}
          </div>
        </div>
      </section>

      <CTA />
    </div>
  );
}
