import { lazy, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import Breadcrumbs from '../components/Breadcrumbs';
import Scene3D from '../components/Scene3D';
import CTA from '../components/CTA';
import {
  TECH_CATEGORIES,
  TECHNOLOGIES,
  type TechCategory,
} from '../data/technologies';
import { useSEO } from '../hooks/useSEO';

const LazyTechnologyScene = lazy(() => import('../scenes/TechnologyScene'));

export default function Technology() {
  useSEO({
    title: 'Technology Stack | React, Next.js, AI, Unity 3D & Java — Supan Desai',
    description:
      'Explore Supan Desai’s interactive 3D technology stack covering React.js, Next.js, Node.js, Java, C++, Unity 3D, Python, OpenAI API, TensorFlow, Firebase, MongoDB, Tailwind CSS, and Figma.',
    path: '/technology',
  });

  const [activeCategory, setActiveCategory] = useState<TechCategory | 'All'>('All');
  const [selectedTechId, setSelectedTechId] = useState<string>(TECHNOLOGIES[0].id);

  const visibleTechs =
    activeCategory === 'All'
      ? TECHNOLOGIES
      : TECHNOLOGIES.filter((t) => t.category === activeCategory);

  const selectedTech =
    TECHNOLOGIES.find((t) => t.id === selectedTechId) ?? TECHNOLOGIES[0];

  return (
    <div className="pt-28 bg-slate-900">
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-6">
          <Breadcrumbs items={[{ label: 'Technology Stack' }]} />

          <div className="max-w-3xl mb-10">
            <h1 className="text-4xl md:text-5xl font-black text-white mb-4">
              Interactive{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
                Technology Stack
              </span>
            </h1>
            <p className="text-lg text-slate-400 leading-relaxed">
              The core languages, frameworks, AI APIs, and engines powering web
              platforms, automation assistants, mobile apps, and 2D/3D games.
            </p>
          </div>

          {/* Category Filters */}
          <div
            className="flex flex-wrap gap-2 mb-8"
            role="tablist"
            aria-label="Filter technologies by category"
          >
            <button
              type="button"
              onClick={() => setActiveCategory('All')}
              className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors ${
                activeCategory === 'All'
                  ? 'bg-cyan-500 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
              }`}
            >
              All ({TECHNOLOGIES.length})
            </button>
            {TECH_CATEGORIES.map((category) => (
              <button
                key={category}
                type="button"
                onClick={() => setActiveCategory(category)}
                className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors ${
                  activeCategory === category
                    ? 'bg-cyan-500 text-white'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* 3D Constellation + Inspector */}
          <div className="grid lg:grid-cols-12 gap-6 mb-12 items-stretch">
            <div className="lg:col-span-8">
              <Scene3D loadingLabel="Loading 3D Technology Constellation...">
                <LazyTechnologyScene
                  technologies={TECHNOLOGIES}
                  activeCategory={activeCategory}
                  selectedTechId={selectedTechId}
                  onSelectTech={setSelectedTechId}
                />
              </Scene3D>
            </div>

            <div className="lg:col-span-4 bg-slate-800/70 border border-slate-700 rounded-2xl p-7 flex flex-col justify-between">
              <div>
                <div className="text-xs font-mono text-cyan-400 uppercase tracking-wider mb-2">
                  {selectedTech.category}
                </div>
                <h2 className="text-2xl font-bold text-white mb-3">
                  {selectedTech.name}
                </h2>
                <p className="text-sm text-slate-300 leading-relaxed mb-6">
                  {selectedTech.summary}
                </p>

                <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  Applied In
                </div>
                <ul className="space-y-2 mb-6">
                  {selectedTech.useCases.map((useCase) => (
                    <li
                      key={useCase}
                      className="text-sm text-slate-300 flex items-center gap-2"
                    >
                      <span
                        className="w-1.5 h-1.5 rounded-full shrink-0"
                        style={{ backgroundColor: selectedTech.colorHex }}
                      />
                      <span>{useCase}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <Link
                to="/portfolio"
                className="inline-flex items-center gap-2 text-sm font-semibold text-cyan-400 hover:text-cyan-300 transition-colors pt-4 border-t border-slate-700"
              >
                <span>See Demos in 3D Portfolio</span>
                <ArrowRight size={16} />
              </Link>
            </div>
          </div>

          {/* Interactive Technology Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {visibleTechs.map((tech) => {
              const isSelected = tech.id === selectedTechId;
              return (
                <button
                  key={tech.id}
                  type="button"
                  onClick={() => setSelectedTechId(tech.id)}
                  className={`text-left p-6 rounded-2xl border transition-all duration-200 hover:-translate-y-1 ${
                    isSelected
                      ? 'bg-slate-800 border-cyan-500 shadow-lg shadow-cyan-500/15'
                      : 'bg-slate-800/40 border-slate-700/60 hover:bg-slate-800 hover:border-slate-600'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="font-bold text-lg text-white">
                      {tech.name}
                    </span>
                    <span
                      className="w-3 h-3 rounded-full shrink-0"
                      style={{ backgroundColor: tech.colorHex }}
                      aria-hidden="true"
                    />
                  </div>
                  <div className="text-xs font-mono text-cyan-400 mb-2">
                    {tech.category}
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {tech.summary}
                  </p>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      <CTA />
    </div>
  );
}
