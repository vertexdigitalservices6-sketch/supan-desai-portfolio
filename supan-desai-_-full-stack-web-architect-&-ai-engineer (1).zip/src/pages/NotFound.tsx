import { Link } from 'react-router-dom';
import { ArrowLeft, Compass } from 'lucide-react';
import { useSEO } from '../hooks/useSEO';

export default function NotFound() {
  useSEO({
    title: '404 — Page Not Found | Supan Desai',
    description:
      'The requested page could not be found. Return to Supan Desai’s portfolio homepage, 3D exhibition, or services.',
    path: '/404',
  });

  return (
    <section className="min-h-[78vh] pt-32 pb-20 bg-slate-900 flex items-center justify-center">
      <div className="container mx-auto px-6">
        <div className="max-w-xl mx-auto bg-slate-800/60 border border-slate-700 rounded-3xl p-8 md:p-12 text-center shadow-2xl">
          <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-slate-900 border border-slate-700 flex items-center justify-center text-cyan-400">
            <Compass size={32} />
          </div>
          <div className="text-sm font-mono font-bold text-cyan-400 tracking-widest uppercase mb-2">
            Error 404
          </div>
          <h1 className="text-3xl md:text-4xl font-black text-white mb-4">
            Page Not Found
          </h1>
          <p className="text-slate-400 text-sm md:text-base mb-8 leading-relaxed">
            The route you navigated to does not exist or has been moved. Use
            the shortcuts below to explore the portfolio.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/"
              className="w-full sm:w-auto px-6 py-3 bg-cyan-500 hover:bg-cyan-600 text-white font-bold rounded-lg transition-colors inline-flex items-center justify-center gap-2 text-sm"
            >
              <ArrowLeft size={16} />
              <span>Back to Home</span>
            </Link>
            <Link
              to="/portfolio"
              className="w-full sm:w-auto px-6 py-3 bg-slate-900 hover:bg-slate-700 border border-slate-700 text-white font-bold rounded-lg transition-colors text-sm"
            >
              Open 3D Portfolio
            </Link>
            <Link
              to="/contact"
              className="w-full sm:w-auto px-6 py-3 bg-slate-900 hover:bg-slate-700 border border-slate-700 text-white font-bold rounded-lg transition-colors text-sm"
            >
              Contact
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
