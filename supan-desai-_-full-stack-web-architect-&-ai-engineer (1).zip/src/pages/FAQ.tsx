import { useState } from 'react';
import { Clock, Shield, Zap } from 'lucide-react';
import Breadcrumbs from '../components/Breadcrumbs';
import FAQAccordion from '../components/FAQAccordion';
import CTA from '../components/CTA';
import { FAQS, type FAQItem } from '../data/faqs';
import { useSEO } from '../hooks/useSEO';

const FAQ_CATEGORIES: Array<'All' | FAQItem['category']> = [
  'All',
  'Pricing',
  'Ownership',
  'Deployment',
  'Support',
];

export default function FAQ() {
  const [activeCategory, setActiveCategory] = useState<'All' | FAQItem['category']>('All');

  useSEO({
    title: 'Frequently Asked Questions | Supan Desai — Pricing, IP & Support',
    description:
      'Answers to common questions about Supan Desai’s freelance pricing starting from ₹1,000, 100% source code ownership, hosting deployment, and post-launch support.',
    path: '/faq',
    structuredData: {
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: FAQS.map((f) => ({
        '@type': 'Question',
        name: f.question,
        acceptedAnswer: {
          '@type': 'Answer',
          text: f.answer,
        },
      })),
    },
  });

  const filteredFaqs =
    activeCategory === 'All'
      ? FAQS
      : FAQS.filter((item) => item.category === activeCategory);

  return (
    <div className="pt-28 bg-slate-900">
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-6">
          <Breadcrumbs items={[{ label: 'FAQ' }]} />

          <div className="flex flex-col md:flex-row gap-12">
            <div className="md:w-1/3">
              <h1 className="text-4xl font-black text-white mb-4">
                Common Questions
              </h1>
              <p className="text-slate-400 mb-8 leading-relaxed">
                Answers to common questions about my freelance process, payment,
                and delivery.
              </p>

              <div className="flex flex-col gap-4 bg-slate-800/50 border border-slate-700/70 rounded-2xl p-6">
                <div className="flex items-center gap-3 text-sm text-slate-300">
                  <Shield className="text-green-500 shrink-0" size={20} />
                  <span>100% IP Ownership</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-slate-300">
                  <Clock className="text-cyan-500 shrink-0" size={20} />
                  <span>Fast Turnaround</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-slate-300">
                  <Zap className="text-yellow-500 shrink-0" size={20} />
                  <span>Modern Tech Stack</span>
                </div>
              </div>
            </div>

            <div className="md:w-2/3">
              <div className="flex flex-wrap gap-2 mb-6">
                {FAQ_CATEGORIES.map((category) => (
                  <button
                    key={category}
                    type="button"
                    onClick={() => setActiveCategory(category)}
                    className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors ${
                      activeCategory === category
                        ? 'bg-cyan-500 text-white'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>

              <FAQAccordion items={filteredFaqs} defaultOpenIndex={0} />
            </div>
          </div>
        </div>
      </section>

      <CTA />
    </div>
  );
}
