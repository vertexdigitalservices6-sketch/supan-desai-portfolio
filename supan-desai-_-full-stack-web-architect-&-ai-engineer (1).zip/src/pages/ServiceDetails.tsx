import { Link, useParams } from 'react-router-dom';
import { ArrowRight, Check, ExternalLink } from 'lucide-react';
import Breadcrumbs from '../components/Breadcrumbs';
import ServiceIcon from '../components/ServiceIcon';
import CTA from '../components/CTA';
import NotFound from './NotFound';
import { getServiceBySlug, SERVICES } from '../data/services';
import { PROFILE } from '../data/profile';
import { useSEO } from '../hooks/useSEO';

export default function ServiceDetails() {
  const { slug } = useParams<{ slug: string }>();
  const service = getServiceBySlug(slug);

  useSEO({
    title: service
      ? `${service.navLabel} | Supan Desai — Full Stack & AI`
      : 'Service Not Found | Supan Desai',
    description: service
      ? `${service.desc} Hire Supan Desai for ${service.navLabel}. Starting from ${PROFILE.startingPrice}.`
      : 'The requested service page could not be found.',
    path: slug ? `/services/${slug}` : '/services',
    structuredData: service
      ? {
          '@context': 'https://schema.org',
          '@type': 'Service',
          name: service.title,
          serviceType: service.navLabel,
          description: service.overview,
          provider: {
            '@type': 'Person',
            name: PROFILE.name,
            email: PROFILE.email,
          },
          offers: {
            '@type': 'Offer',
            price: '1000',
            priceCurrency: 'INR',
          },
        }
      : undefined,
  });

  if (!service) {
    return <NotFound />;
  }

  const otherServices = SERVICES.filter((s) => s.slug !== service.slug);

  return (
    <div className="pt-28 bg-slate-900">
      <section className="py-12 md:py-16 border-b border-slate-800">
        <div className="container mx-auto px-6">
          <Breadcrumbs
            items={[
              { label: 'Services', to: '/services' },
              { label: service.navLabel },
            ]}
          />

          <div className="grid lg:grid-cols-12 gap-10 items-start">
            {/* Hero Intro & Overview */}
            <div className="lg:col-span-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-4 bg-slate-800 rounded-2xl border border-slate-700 shadow-inner">
                  <ServiceIcon iconKey={service.iconKey} size={36} />
                </div>
                <div>
                  <span className="text-xs font-mono uppercase tracking-widest text-cyan-400">
                    {service.highlight}
                  </span>
                  <h1 className="text-3xl md:text-5xl font-black text-white mt-1">
                    {service.title}
                  </h1>
                </div>
              </div>

              <p className="text-lg text-slate-300 leading-relaxed mb-6">
                {service.desc}
              </p>
              <p className="text-slate-400 leading-relaxed mb-8">
                {service.overview}
              </p>

              <div className="flex flex-wrap gap-4">
                <Link
                  to="/contact"
                  className="px-7 py-3.5 bg-cyan-500 hover:bg-cyan-600 text-white font-bold rounded-lg transition-colors inline-flex items-center gap-2 text-sm shadow-lg shadow-cyan-500/20"
                >
                  <span>Request Fixed Quote</span>
                  <ArrowRight size={16} />
                </Link>
                <a
                  href={service.primaryOfferUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-7 py-3.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-bold rounded-lg transition-colors inline-flex items-center gap-2 text-sm"
                >
                  <span>{service.primaryOfferLabel}</span>
                  <ExternalLink size={16} />
                </a>
              </div>
            </div>

            {/* Sidebar Snapshot */}
            <div className="lg:col-span-4 bg-slate-800/60 border border-slate-700 rounded-2xl p-6 space-y-5">
              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">
                  Starting From
                </div>
                <div className="text-3xl font-black text-white tabular-nums">
                  {PROFILE.startingPrice}
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Fixed-project pricing with transparent milestones
                </p>
              </div>

              <div className="border-t border-slate-700 pt-4">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  Core Technologies
                </div>
                <div className="flex flex-wrap gap-2">
                  {service.technologies.map((tech) => (
                    <Link
                      key={tech}
                      to="/technology"
                      className="text-xs px-2.5 py-1 bg-slate-900 rounded text-slate-300 hover:text-cyan-400 font-mono border border-slate-700 transition-colors"
                    >
                      {tech}
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features & Benefits */}
      <section className="py-16 bg-slate-950">
        <div className="container mx-auto px-6 grid md:grid-cols-2 gap-8">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8">
            <h2 className="text-2xl font-bold text-white mb-6">
              Included Capabilities &amp; Features
            </h2>
            <ul className="space-y-4">
              {service.features.map((feature) => (
                <li key={feature} className="flex items-start gap-3 text-slate-300 text-sm">
                  <span className="p-1 rounded bg-cyan-500/15 text-cyan-400 mt-0.5 shrink-0">
                    <Check size={14} />
                  </span>
                  <span className="leading-relaxed">{feature}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8">
            <h2 className="text-2xl font-bold text-white mb-6">
              Key Client Benefits
            </h2>
            <ul className="space-y-4">
              {service.benefits.map((benefit) => (
                <li key={benefit} className="flex items-start gap-3 text-slate-300 text-sm">
                  <span className="p-1 rounded bg-green-500/15 text-green-400 mt-0.5 shrink-0">
                    <Check size={14} />
                  </span>
                  <span className="leading-relaxed">{benefit}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Development Workflow */}
      <section className="py-16 bg-slate-900 border-t border-slate-800">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-white mb-10">
            Development Workflow
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            {service.workflow.map((item) => (
              <div
                key={item.step}
                className="bg-slate-800/50 border border-slate-700/70 rounded-2xl p-7"
              >
                <div className="text-xs font-mono font-bold text-cyan-400 mb-3">
                  STEP {item.step}
                </div>
                <h3 className="text-xl font-bold text-white mb-2">
                  {item.title}
                </h3>
                <p className="text-sm text-slate-400 leading-relaxed">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Explore Other Services */}
      <section className="py-14 bg-slate-950 border-t border-slate-800">
        <div className="container mx-auto px-6">
          <h2 className="text-xl font-bold text-white mb-6">
            Other Services by {PROFILE.name}
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {otherServices.map((other) => (
              <Link
                key={other.slug}
                to={`/services/${other.slug}`}
                className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/50 transition-colors group"
              >
                <div className="mb-2">
                  <ServiceIcon iconKey={other.iconKey} size={22} />
                </div>
                <div className="font-bold text-sm text-white group-hover:text-cyan-400 transition-colors">
                  {other.navLabel}
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <CTA
        title={`Start Your ${service.navLabel} Project`}
        description={`Reach out directly at ${PROFILE.email} or ${PROFILE.phoneDisplay} for a transparent fixed quote starting from ${PROFILE.startingPrice}.`}
      />
    </div>
  );
}
