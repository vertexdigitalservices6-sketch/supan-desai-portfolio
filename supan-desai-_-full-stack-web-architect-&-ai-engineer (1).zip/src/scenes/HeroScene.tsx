import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { detectSoftwareWebGL, scheduleSoftwareFrame, supportsWebGL } from '../utils/webgl';
import { useReducedMotion } from '../hooks/useReducedMotion';

interface HeroSceneProps {
  className?: string;
}

function createParticleTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 64;
  canvas.height = 64;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
  grad.addColorStop(0, 'rgba(255, 255, 255, 1)');
  grad.addColorStop(0.35, 'rgba(34, 211, 238, 0.85)');
  grad.addColorStop(1, 'rgba(15, 23, 42, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 64, 64);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export default function HeroScene({ className = '' }: HeroSceneProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const reducedMotion = useReducedMotion();
  const [fallbackMode, setFallbackMode] = useState<boolean>(() => !supportsWebGL());

  useEffect(() => {
    if (reducedMotion || fallbackMode) return;
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareWebGL();
    let frameId = 0;
    let disposed = false;
    let contextLost = false;

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(48, width / height, 0.1, 100);
    camera.position.set(0, 0.2, 7.2);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        alpha: true,
        powerPreference: 'high-performance',
      });
    } catch {
      setFallbackMode(true);
      return;
    }

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    renderer.setClearColor(0x000000, 0);

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Studio environment for metallic orbital rings
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTarget = pmremGenerator.fromScene(new RoomEnvironment(), 0.04);
    scene.environment = envTarget.texture;
    pmremGenerator.dispose();

    // Balanced lighting
    const hemiLight = new THREE.HemisphereLight(0x38bdf8, 0x0f172a, 0.7);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xe0f2fe, 1.4);
    keyLight.position.set(5, 6, 5);
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x3b82f6, 1.0);
    rimLight.position.set(-5, -3, -4);
    scene.add(rimLight);

    // Composite futuristic wireframe sphere group
    const sphereGroup = new THREE.Group();
    sphereGroup.position.set(0, 0.1, 0);
    scene.add(sphereGroup);

    // 1. Inner core polyhedron
    const coreGeo = new THREE.IcosahedronGeometry(1.1, 1);
    const coreMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      emissive: 0x0891b2,
      emissiveIntensity: 0.45,
      metalness: 0.85,
      roughness: 0.2,
      flatShading: true,
    });
    const coreMesh = new THREE.Mesh(coreGeo, coreMat);
    sphereGroup.add(coreMesh);

    // 2. Primary cyan wireframe sphere
    const innerWireGeo = new THREE.IcosahedronGeometry(1.65, 2);
    const innerWireMat = new THREE.MeshBasicMaterial({
      color: 0x22d3ee,
      wireframe: true,
      transparent: true,
      opacity: 0.34,
    });
    const innerWire = new THREE.Mesh(innerWireGeo, innerWireMat);
    sphereGroup.add(innerWire);

    // 3. Outer blue geodesic shell
    const outerWireGeo = new THREE.IcosahedronGeometry(2.25, 1);
    const outerWireMat = new THREE.MeshBasicMaterial({
      color: 0x3b82f6,
      wireframe: true,
      transparent: true,
      opacity: 0.22,
    });
    const outerWire = new THREE.Mesh(outerWireGeo, outerWireMat);
    sphereGroup.add(outerWire);

    // 4. Orbital precision rings
    const ringGeo1 = new THREE.TorusGeometry(2.55, 0.018, 12, 96);
    const ringMat1 = new THREE.MeshStandardMaterial({
      color: 0x06b6d4,
      emissive: 0x06b6d4,
      emissiveIntensity: 0.35,
      metalness: 0.9,
      roughness: 0.2,
    });
    const ring1 = new THREE.Mesh(ringGeo1, ringMat1);
    ring1.rotation.x = Math.PI * 0.38;
    ring1.rotation.y = Math.PI * 0.14;
    sphereGroup.add(ring1);

    const ringGeo2 = new THREE.TorusGeometry(2.85, 0.014, 12, 96);
    const ringMat2 = new THREE.MeshStandardMaterial({
      color: 0x3b82f6,
      emissive: 0x2563eb,
      emissiveIntensity: 0.25,
      metalness: 0.85,
      roughness: 0.3,
    });
    const ring2 = new THREE.Mesh(ringGeo2, ringMat2);
    ring2.rotation.x = -Math.PI * 0.28;
    ring2.rotation.y = -Math.PI * 0.22;
    sphereGroup.add(ring2);

    // 5. Orbiting satellite nodes via InstancedMesh
    const nodeCount = 24;
    const nodeGeo = new THREE.OctahedronGeometry(0.055, 0);
    const nodeMat = new THREE.MeshStandardMaterial({
      color: 0x67e8f9,
      emissive: 0x06b6d4,
      emissiveIntensity: 0.7,
      metalness: 0.6,
      roughness: 0.2,
    });
    const nodesInstanced = new THREE.InstancedMesh(nodeGeo, nodeMat, nodeCount);
    const dummy = new THREE.Object3D();
    for (let i = 0; i < nodeCount; i++) {
      const phi = Math.acos(1 - (2 * (i + 0.5)) / nodeCount);
      const theta = Math.PI * (1 + Math.sqrt(5)) * i;
      const radius = 2.28;
      dummy.position.set(
        radius * Math.sin(phi) * Math.cos(theta),
        radius * Math.sin(phi) * Math.sin(theta),
        radius * Math.cos(phi)
      );
      dummy.updateMatrix();
      nodesInstanced.setMatrixAt(i, dummy.matrix);
    }
    nodesInstanced.instanceMatrix.needsUpdate = true;
    nodesInstanced.computeBoundingSphere();
    sphereGroup.add(nodesInstanced);

    // 6. Floating cyan & blue particles
    const particleCount = isSoftwareGl ? 160 : 260;
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);
    const cyanColor = new THREE.Color(0x22d3ee);
    const blueColor = new THREE.Color(0x3b82f6);

    for (let i = 0; i < particleCount; i++) {
      const r = 2.8 + Math.random() * 4.5;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta) * 0.72;
      positions[i * 3 + 2] = r * Math.cos(phi) - 0.8;

      const mixColor = i % 2 === 0 ? cyanColor : blueColor;
      colors[i * 3] = mixColor.r;
      colors[i * 3 + 1] = mixColor.g;
      colors[i * 3 + 2] = mixColor.b;
    }

    const particleGeo = new THREE.BufferGeometry();
    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    const particleTexture = createParticleTexture();
    const particleMat = new THREE.PointsMaterial({
      size: 0.14,
      map: particleTexture,
      vertexColors: true,
      transparent: true,
      opacity: 0.75,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // Pointer tracking without allocations
    let targetPointerX = 0;
    let targetPointerY = 0;
    let smoothPointerX = 0;
    let smoothPointerY = 0;

    const handlePointerMove = (e: PointerEvent) => {
      targetPointerX = (e.clientX / window.innerWidth) * 2 - 1;
      targetPointerY = -(e.clientY / window.innerHeight) * 2 + 1;
    };

    const handleResize = () => {
      if (!container || disposed) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    const handleContextLost = (e: Event) => {
      e.preventDefault();
      contextLost = true;
    };

    const handleContextRestored = () => {
      contextLost = false;
    };

    window.addEventListener('pointermove', handlePointerMove, { passive: true });
    window.addEventListener('resize', handleResize);
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);
    renderer.domElement.addEventListener('webglcontextrestored', handleContextRestored);

    const clock = new THREE.Clock();

    const tick = () => {
      if (disposed) return;

      if (document.hidden || contextLost) {
        if (isSoftwareGl) {
          frameId = window.setTimeout(tick, 200);
        } else {
          frameId = requestAnimationFrame(tick);
        }
        return;
      }

      const delta = Math.min(clock.getDelta(), 0.05);
      const elapsed = clock.getElapsedTime();

      smoothPointerX = THREE.MathUtils.damp(smoothPointerX, targetPointerX, 4, delta);
      smoothPointerY = THREE.MathUtils.damp(smoothPointerY, targetPointerY, 4, delta);

      sphereGroup.rotation.y = elapsed * 0.16 + smoothPointerX * 0.35;
      sphereGroup.rotation.x = Math.sin(elapsed * 0.25) * 0.08 + smoothPointerY * 0.25;

      innerWire.rotation.y -= delta * 0.14;
      outerWire.rotation.x += delta * 0.08;
      ring1.rotation.z += delta * 0.22;
      ring2.rotation.z -= delta * 0.18;

      particles.rotation.y = elapsed * 0.04 + smoothPointerX * 0.12;
      particles.rotation.x = smoothPointerY * 0.08;

      camera.position.x = THREE.MathUtils.damp(camera.position.x, smoothPointerX * 0.35, 3, delta);
      camera.position.y = THREE.MathUtils.damp(camera.position.y, 0.2 + smoothPointerY * 0.22, 3, delta);
      camera.lookAt(0, 0.1, 0);

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        scheduleSoftwareFrame(renderer, tick, (id) => {
          frameId = id;
        });
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };

    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      renderer.domElement.removeEventListener('webglcontextrestored', handleContextRestored);

      coreGeo.dispose();
      coreMat.dispose();
      innerWireGeo.dispose();
      innerWireMat.dispose();
      outerWireGeo.dispose();
      outerWireMat.dispose();
      ringGeo1.dispose();
      ringMat1.dispose();
      ringGeo2.dispose();
      ringMat2.dispose();
      nodeGeo.dispose();
      nodeMat.dispose();
      particleGeo.dispose();
      particleMat.dispose();
      particleTexture.dispose();
      envTarget.dispose();
      renderer.dispose();
      if (renderer.domElement.parentElement === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [reducedMotion, fallbackMode]);

  if (reducedMotion || fallbackMode) {
    return (
      <div
        className={`relative w-full h-full flex items-center justify-center overflow-hidden pointer-events-none ${className}`}
        aria-hidden="true"
      >
        <div className="relative w-72 h-72 md:w-[440px] md:h-[440px] flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border border-cyan-500/20 animate-float-slow" />
          <div className="absolute inset-8 rounded-full border border-dashed border-blue-500/25 rotate-12" />
          <div className="absolute inset-16 rounded-full border border-cyan-400/25 -rotate-12" />
          <div className="w-40 h-40 rounded-full bg-gradient-to-br from-cyan-500/15 to-blue-600/15 blur-xl" />
        </div>
      </div>
    );
  }

  return (
    <div
      ref={mountRef}
      className={`w-full h-full pointer-events-none select-none ${className}`}
      aria-hidden="true"
    />
  );
}
