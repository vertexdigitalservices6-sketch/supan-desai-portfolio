import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { ChevronLeft, ChevronRight, ArrowUpRight, RotateCcw } from 'lucide-react';
import type { PortfolioProject } from '../data/projects';
import {
  createProjectCardTexture,
  detectSoftwareWebGL,
  scheduleSoftwareFrame,
  supportsWebGL,
} from '../utils/webgl';
import { useReducedMotion } from '../hooks/useReducedMotion';

interface PortfolioSceneProps {
  projects: PortfolioProject[];
  selectedIndex: number;
  onSelectIndex: (index: number) => void;
  onInspectProject: (slug: string) => void;
}

export default function PortfolioScene({
  projects,
  selectedIndex,
  onSelectIndex,
  onInspectProject,
}: PortfolioSceneProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const reducedMotion = useReducedMotion();
  const [fallbackMode, setFallbackMode] = useState<boolean>(() => !supportsWebGL());

  const selectedIndexRef = useRef(selectedIndex);
  selectedIndexRef.current = selectedIndex;

  const onSelectRef = useRef(onSelectIndex);
  onSelectRef.current = onSelectIndex;

  const onInspectRef = useRef(onInspectProject);
  onInspectRef.current = onInspectProject;

  const projectsKey = projects.map((p) => p.slug).join('|');

  useEffect(() => {
    if (reducedMotion || fallbackMode || projects.length === 0) return;
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareWebGL();
    let frameId = 0;
    let disposed = false;
    let contextLost = false;

    const width = container.clientWidth || 960;
    const height = container.clientHeight || 480;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x020617);
    scene.fog = new THREE.FogExp2(0x020617, 0.045);

    const camera = new THREE.PerspectiveCamera(44, width / height, 0.1, 100);
    camera.position.set(0, 1.35, 8.8);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance',
      });
    } catch {
      setFallbackMode(true);
      return;
    }

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTarget = pmremGenerator.fromScene(new RoomEnvironment(), 0.04);
    scene.environment = envTarget.texture;
    pmremGenerator.dispose();

    // Three-point studio lighting + hemisphere fill
    const hemiLight = new THREE.HemisphereLight(0x38bdf8, 0x0f172a, 0.65);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xf8fafc, 1.4);
    keyLight.position.set(4, 7, 6);
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x06b6d4, 0.9);
    rimLight.position.set(-5, 3, -5);
    scene.add(rimLight);

    // Subtle exhibition floor rings
    const floorRingGeo = new THREE.RingGeometry(2.6, 5.4, 64);
    const floorRingMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      metalness: 0.75,
      roughness: 0.35,
      side: THREE.DoubleSide,
    });
    const floorRing = new THREE.Mesh(floorRingGeo, floorRingMat);
    floorRing.rotation.x = -Math.PI / 2;
    floorRing.position.y = -1.62;
    scene.add(floorRing);

    const gridHelper = new THREE.GridHelper(22, 22, 0x1e293b, 0x0f172a);
    gridHelper.position.y = -1.64;
    scene.add(gridHelper);

    // Carousel group
    const carouselGroup = new THREE.Group();
    scene.add(carouselGroup);

    const count = projects.length;
    const radius = count <= 2 ? 2.4 : Math.max(3.6, count * 0.72);
    const angleStep = (Math.PI * 2) / count;

    const disposableGeos: THREE.BufferGeometry[] = [floorRingGeo];
    const disposableMats: THREE.Material[] = [floorRingMat];
    const disposableTextures: THREE.Texture[] = [];
    const clickableMeshes: THREE.Mesh[] = [];
    const cardGroups: THREE.Group[] = [];

    const frameGeo = new THREE.BoxGeometry(2.74, 1.84, 0.09);
    const screenGeo = new THREE.PlaneGeometry(2.6, 1.72);
    const barGeo = new THREE.BoxGeometry(2.4, 0.05, 0.12);
    const plinthGeo = new THREE.CylinderGeometry(0.6, 0.78, 0.14, 24);
    disposableGeos.push(frameGeo, screenGeo, barGeo, plinthGeo);

    const frameMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      metalness: 0.85,
      roughness: 0.25,
    });
    const plinthMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      metalness: 0.7,
      roughness: 0.4,
    });
    disposableMats.push(frameMat, plinthMat);

    const maxAniso = renderer.capabilities.getMaxAnisotropy();

    projects.forEach((project, index) => {
      const cardGroup = new THREE.Group();
      const angle = index * angleStep;

      cardGroup.position.set(
        Math.sin(angle) * radius,
        0,
        Math.cos(angle) * radius
      );
      cardGroup.rotation.y = angle;

      // 1. Metallic bezel housing
      const frameMesh = new THREE.Mesh(frameGeo, frameMat);
      cardGroup.add(frameMesh);

      // 2. Front screen with procedural high-DPI texture
      const tex = createProjectCardTexture(
        project.title,
        project.category,
        project.technologies,
        project.accentHex,
        project.secondaryHex,
        index === selectedIndexRef.current
      );
      tex.anisotropy = maxAniso;
      disposableTextures.push(tex);

      const screenMat = new THREE.MeshStandardMaterial({
        map: tex,
        roughness: 0.35,
        metalness: 0.15,
      });
      disposableMats.push(screenMat);

      const screenMesh = new THREE.Mesh(screenGeo, screenMat);
      screenMesh.position.z = 0.052;
      screenMesh.userData.projectIndex = index;
      screenMesh.userData.projectSlug = project.slug;
      screenMesh.layers.enable(1);
      cardGroup.add(screenMesh);
      clickableMeshes.push(screenMesh);

      // 3. Glowing accent bar along bottom rim
      const accentColor = new THREE.Color(project.accentHex);
      const barMat = new THREE.MeshStandardMaterial({
        color: accentColor,
        emissive: accentColor,
        emissiveIntensity: 0.65,
        metalness: 0.4,
        roughness: 0.2,
      });
      disposableMats.push(barMat);
      const barMesh = new THREE.Mesh(barGeo, barMat);
      barMesh.position.set(0, -0.98, 0);
      cardGroup.add(barMesh);

      // 4. Exhibition plinth beneath card
      const plinthMesh = new THREE.Mesh(plinthGeo, plinthMat);
      plinthMesh.position.set(0, -1.52, 0);
      cardGroup.add(plinthMesh);

      cardGroups.push(cardGroup);
      carouselGroup.add(cardGroup);
    });

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // Raycasting for card click & hover
    const raycaster = new THREE.Raycaster();
    raycaster.layers.set(1);
    const pointer = new THREE.Vector2();
    let lastHoverTime = 0;
    let hoveredIndex = -1;

    const updatePointer = (e: PointerEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    };

    const handlePointerMove = (e: PointerEvent) => {
      const now = performance.now();
      if (now - lastHoverTime < 50) return;
      lastHoverTime = now;

      updatePointer(e);
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects(clickableMeshes, false);
      if (hits.length > 0) {
        hoveredIndex = hits[0].object.userData.projectIndex ?? -1;
        renderer.domElement.style.cursor = 'pointer';
      } else {
        hoveredIndex = -1;
        renderer.domElement.style.cursor = 'default';
      }
    };

    const handleClick = (e: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects(clickableMeshes, false);
      if (hits.length > 0) {
        const idx = hits[0].object.userData.projectIndex as number;
        const slug = hits[0].object.userData.projectSlug as string;
        if (idx === selectedIndexRef.current && slug) {
          onInspectRef.current(slug);
        } else if (typeof idx === 'number') {
          onSelectRef.current(idx);
        }
      }
    };

    const handleResize = () => {
      if (!container || disposed) return;
      const w = container.clientWidth || 960;
      const h = container.clientHeight || 480;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    const handleContextLost = (e: Event) => {
      e.preventDefault();
      contextLost = true;
    };

    const handleContextRestored = () => {
      contextLost = false;
    };

    renderer.domElement.addEventListener('pointermove', handlePointerMove);
    renderer.domElement.addEventListener('click', handleClick);
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);
    renderer.domElement.addEventListener('webglcontextrestored', handleContextRestored);
    window.addEventListener('resize', handleResize);

    // Smooth carousel rotation tracking shortest angular path
    let currentYaw = -selectedIndexRef.current * angleStep;
    const clock = new THREE.Clock();

    const tick = () => {
      if (disposed) return;

      if (document.hidden || contextLost) {
        if (isSoftwareGl) {
          frameId = window.setTimeout(tick, 200);
        } else {
          frameId = requestAnimationFrame(tick);
        }
        return;
      }

      const delta = Math.min(clock.getDelta(), 0.05);
      const elapsed = clock.getElapsedTime();

      const targetYaw = -selectedIndexRef.current * angleStep;
      let diff = targetYaw - currentYaw;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      currentYaw = THREE.MathUtils.damp(currentYaw, currentYaw + diff, 6.5, delta);
      carouselGroup.rotation.y = currentYaw;

      // Subtle elevation & hover emphasis per card
      for (let i = 0; i < cardGroups.length; i++) {
        const group = cardGroups[i];
        const isActive = i === selectedIndexRef.current;
        const isHovered = i === hoveredIndex;
        const targetY = isActive ? 0.16 + Math.sin(elapsed * 1.6) * 0.04 : 0;
        const targetScale = isActive ? 1.07 : isHovered ? 1.02 : 0.94;
        group.position.y = THREE.MathUtils.damp(group.position.y, targetY, 6, delta);
        const s = THREE.MathUtils.damp(group.scale.x, targetScale, 7, delta);
        group.scale.set(s, s, s);
      }

      // Camera gently frames the active front exhibition stand
      const targetCamZ = radius + 4.35;
      camera.position.z = THREE.MathUtils.damp(camera.position.z, targetCamZ, 5, delta);
      camera.position.y = THREE.MathUtils.damp(camera.position.y, 0.72, 5, delta);
      camera.lookAt(0, 0.05, radius * 0.55);

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        scheduleSoftwareFrame(renderer, tick, (id) => {
          frameId = id;
        });
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };

    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      renderer.domElement.removeEventListener('pointermove', handlePointerMove);
      renderer.domElement.removeEventListener('click', handleClick);
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      renderer.domElement.removeEventListener('webglcontextrestored', handleContextRestored);
      window.removeEventListener('resize', handleResize);

      disposableGeos.forEach((g) => g.dispose());
      disposableMats.forEach((m) => m.dispose());
      disposableTextures.forEach((t) => t.dispose());
      envTarget.dispose();
      renderer.dispose();
      if (renderer.domElement.parentElement === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [projectsKey, reducedMotion, fallbackMode]);

  const activeProject = projects[selectedIndex] ?? projects[0];
  const handlePrev = () =>
    onSelectIndex((selectedIndex - 1 + projects.length) % projects.length);
  const handleNext = () => onSelectIndex((selectedIndex + 1) % projects.length);

  if (reducedMotion || fallbackMode) {
    return (
      <div className="relative rounded-2xl border border-slate-800 bg-slate-950 p-6 md:p-10 overflow-hidden">
        <div className="text-center mb-6">
          <span className="text-xs font-mono uppercase tracking-wider text-cyan-400">
            Interactive CSS 3D Exhibition Fallback
          </span>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 perspective-1000">
          {projects.map((project, idx) => {
            const isSelected = idx === selectedIndex;
            return (
              <button
                key={project.slug}
                type="button"
                onClick={() =>
                  isSelected ? onInspectProject(project.slug) : onSelectIndex(idx)
                }
                className={`text-left p-5 rounded-xl border transition-all duration-300 transform hover:-translate-y-1 ${
                  isSelected
                    ? 'bg-slate-800 border-cyan-500 shadow-lg shadow-cyan-500/15'
                    : 'bg-slate-900 border-slate-800 hover:border-slate-600'
                }`}
              >
                <div className="text-xs font-mono text-cyan-400 mb-1">
                  {project.category} · Demo Placeholder
                </div>
                <h3 className="text-lg font-bold text-white mb-2">{project.title}</h3>
                <p className="text-xs text-slate-400 line-clamp-2 mb-3">
                  {project.shortDesc}
                </p>
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-cyan-400">
                  {isSelected ? 'Open Project Details' : 'Focus Stand'}{' '}
                  <ArrowUpRight size={14} />
                </span>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div className="relative rounded-2xl border border-slate-800 bg-slate-950 overflow-hidden shadow-2xl">
      {/* Top minimal overlay caption */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 border-b border-slate-800/80 bg-slate-950">
        <div className="flex items-center gap-3 text-xs text-slate-400">
          <span className="font-semibold text-cyan-400">3D Spatial Carousel</span>
          <span aria-hidden="true">·</span>
          <span>Click any stand to focus, click focused stand to open</span>
        </div>
        <div className="text-xs font-mono text-slate-400 tabular-nums">
          Stand {selectedIndex + 1} / {projects.length}
        </div>
      </div>

      {/* 3D Canvas Viewport */}
      <div
        ref={mountRef}
        className="w-full h-[380px] sm:h-[440px] md:h-[490px] bg-slate-950"
      />

      {/* Unified Bottom Control Dock */}
      {activeProject && (
        <div className="border-t border-slate-800 bg-slate-900/95 px-5 py-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-cyan-400 mb-1">
              <span>{activeProject.category}</span>
              <span aria-hidden="true">·</span>
              <span className="text-amber-400">Editable Demo Placeholder</span>
            </div>
            <h3 className="text-lg font-bold text-white truncate">
              {activeProject.title}
            </h3>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handlePrev}
              aria-label="Previous project stand"
              className="p-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 transition-colors"
            >
              <ChevronLeft size={18} />
            </button>
            <button
              type="button"
              onClick={handleNext}
              aria-label="Next project stand"
              className="p-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 transition-colors"
            >
              <ChevronRight size={18} />
            </button>
            <button
              type="button"
              onClick={() => onSelectIndex(0)}
              aria-label="Reset carousel focus"
              className="p-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 transition-colors"
              title="Reset to first stand"
            >
              <RotateCcw size={16} />
            </button>
            <button
              type="button"
              onClick={() => onInspectProject(activeProject.slug)}
              className="px-4 py-2.5 rounded-lg bg-cyan-500 hover:bg-cyan-600 text-white text-sm font-bold transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
            >
              Inspect Details <ArrowUpRight size={16} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
