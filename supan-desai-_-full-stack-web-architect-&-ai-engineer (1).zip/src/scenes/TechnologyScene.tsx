import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import type { TechCategory, TechnologyItem } from '../data/technologies';
import {
  detectSoftwareWebGL,
  scheduleSoftwareFrame,
  supportsWebGL,
} from '../utils/webgl';
import { useReducedMotion } from '../hooks/useReducedMotion';

interface TechnologySceneProps {
  technologies: TechnologyItem[];
  activeCategory: TechCategory | 'All';
  selectedTechId: string;
  onSelectTech: (techId: string) => void;
}

function createTechLabelSprite(label: string, colorHex: string, highlighted: boolean): THREE.Sprite {
  const canvas = document.createElement('canvas');
  canvas.width = 320;
  canvas.height = 96;
  const ctx = canvas.getContext('2d')!;

  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = highlighted ? 'rgba(15, 23, 42, 0.96)' : 'rgba(15, 23, 42, 0.82)';
  ctx.strokeStyle = highlighted ? colorHex : 'rgba(71, 85, 105, 0.85)';
  ctx.lineWidth = highlighted ? 4 : 2;

  ctx.beginPath();
  ctx.roundRect(12, 16, canvas.width - 24, canvas.height - 32, 16);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = highlighted ? '#ffffff' : '#cbd5e1';
  ctx.font = 'bold 30px Inter, system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(label, canvas.width / 2, canvas.height / 2 + 1);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  const material = new THREE.SpriteMaterial({
    map: texture,
    transparent: true,
    depthWrite: false,
  });
  const sprite = new THREE.Sprite(material);
  sprite.scale.set(1.55, 0.46, 1);
  return sprite;
}

export default function TechnologyScene({
  technologies,
  activeCategory,
  selectedTechId,
  onSelectTech,
}: TechnologySceneProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const reducedMotion = useReducedMotion();
  const [fallbackMode, setFallbackMode] = useState<boolean>(() => !supportsWebGL());

  const activeCategoryRef = useRef(activeCategory);
  activeCategoryRef.current = activeCategory;

  const selectedTechRef = useRef(selectedTechId);
  selectedTechRef.current = selectedTechId;

  const onSelectRef = useRef(onSelectTech);
  onSelectRef.current = onSelectTech;

  useEffect(() => {
    if (reducedMotion || fallbackMode) return;
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareWebGL();
    let frameId = 0;
    let disposed = false;
    let contextLost = false;

    const width = container.clientWidth || 900;
    const height = container.clientHeight || 420;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x020617);
    scene.fog = new THREE.FogExp2(0x020617, 0.04);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 1.8, 9.2);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance',
      });
    } catch {
      setFallbackMode(true);
      return;
    }

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTarget = pmremGenerator.fromScene(new RoomEnvironment(), 0.04);
    scene.environment = envTarget.texture;
    pmremGenerator.dispose();

    const hemi = new THREE.HemisphereLight(0x38bdf8, 0x0f172a, 0.7);
    scene.add(hemi);
    const key = new THREE.DirectionalLight(0xf8fafc, 1.3);
    key.position.set(5, 7, 5);
    scene.add(key);

    const constellationGroup = new THREE.Group();
    scene.add(constellationGroup);

    // Central architectural core
    const centerCoreGeo = new THREE.OctahedronGeometry(0.72, 1);
    const centerCoreMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      emissive: 0x06b6d4,
      emissiveIntensity: 0.45,
      metalness: 0.9,
      roughness: 0.2,
      wireframe: true,
    });
    const centerCore = new THREE.Mesh(centerCoreGeo, centerCoreMat);
    constellationGroup.add(centerCore);

    const orbitRingGeo = new THREE.TorusGeometry(3.5, 0.015, 12, 96);
    const orbitRingMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      emissive: 0x0284c7,
      emissiveIntensity: 0.3,
      metalness: 0.8,
      roughness: 0.3,
    });
    const orbitRing = new THREE.Mesh(orbitRingGeo, orbitRingMat);
    orbitRing.rotation.x = Math.PI / 2.2;
    constellationGroup.add(orbitRing);

    const disposableGeos: THREE.BufferGeometry[] = [centerCoreGeo, orbitRingGeo];
    const disposableMats: THREE.Material[] = [centerCoreMat, orbitRingMat];
    const disposableTextures: THREE.Texture[] = [];

    const nodeGeo = new THREE.IcosahedronGeometry(0.28, 0);
    disposableGeos.push(nodeGeo);

    interface NodeRecord {
      tech: TechnologyItem;
      group: THREE.Group;
      mesh: THREE.Mesh;
      mat: THREE.MeshStandardMaterial;
      basePos: THREE.Vector3;
    }

    const nodeRecords: NodeRecord[] = [];
    const clickableMeshes: THREE.Mesh[] = [];

    technologies.forEach((tech, index) => {
      const angle = (index / technologies.length) * Math.PI * 2;
      const radius = index % 2 === 0 ? 3.45 : 2.35;
      const yOffset = ((index % 3) - 1) * 0.72;
      const basePos = new THREE.Vector3(
        Math.cos(angle) * radius,
        yOffset,
        Math.sin(angle) * radius
      );

      const nodeGroup = new THREE.Group();
      nodeGroup.position.copy(basePos);

      const mat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(tech.colorHex),
        emissive: new THREE.Color(tech.colorHex),
        emissiveIntensity: 0.35,
        metalness: 0.7,
        roughness: 0.25,
      });
      disposableMats.push(mat);

      const mesh = new THREE.Mesh(nodeGeo, mat);
      mesh.userData.techId = tech.id;
      mesh.layers.enable(1);
      nodeGroup.add(mesh);
      clickableMeshes.push(mesh);

      const sprite = createTechLabelSprite(
        tech.name,
        tech.colorHex,
        tech.id === selectedTechRef.current
      );
      sprite.position.set(0, 0.56, 0);
      if (sprite.material.map) disposableTextures.push(sprite.material.map);
      disposableMats.push(sprite.material);
      nodeGroup.add(sprite);

      constellationGroup.add(nodeGroup);
      nodeRecords.push({ tech, group: nodeGroup, mesh, mat, basePos });
    });

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    const raycaster = new THREE.Raycaster();
    raycaster.layers.set(1);
    const pointer = new THREE.Vector2();
    let pointerX = 0;

    const handlePointerMove = (e: PointerEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      pointerX = pointer.x;
    };

    const handleClick = (e: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects(clickableMeshes, false);
      if (hits.length > 0 && hits[0].object.userData.techId) {
        onSelectRef.current(hits[0].object.userData.techId as string);
      }
    };

    const handleResize = () => {
      if (!container || disposed) return;
      const w = container.clientWidth || 900;
      const h = container.clientHeight || 420;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    const handleContextLost = (e: Event) => {
      e.preventDefault();
      contextLost = true;
    };

    const handleContextRestored = () => {
      contextLost = false;
    };

    renderer.domElement.addEventListener('pointermove', handlePointerMove);
    renderer.domElement.addEventListener('click', handleClick);
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);
    renderer.domElement.addEventListener('webglcontextrestored', handleContextRestored);
    window.addEventListener('resize', handleResize);

    const clock = new THREE.Clock();

    const tick = () => {
      if (disposed) return;
      if (document.hidden || contextLost) {
        if (isSoftwareGl) frameId = window.setTimeout(tick, 200);
        else frameId = requestAnimationFrame(tick);
        return;
      }

      const delta = Math.min(clock.getDelta(), 0.05);
      const elapsed = clock.getElapsedTime();

      constellationGroup.rotation.y = elapsed * 0.14 + pointerX * 0.28;
      centerCore.rotation.x += delta * 0.45;
      centerCore.rotation.y -= delta * 0.3;

      for (let i = 0; i < nodeRecords.length; i++) {
        const rec = nodeRecords[i];
        const isSelected = rec.tech.id === selectedTechRef.current;
        const matchesCat =
          activeCategoryRef.current === 'All' ||
          rec.tech.category === activeCategoryRef.current;

        const targetScale = isSelected ? 1.38 : matchesCat ? 1.0 : 0.65;
        const s = THREE.MathUtils.damp(rec.mesh.scale.x, targetScale, 6, delta);
        rec.mesh.scale.set(s, s, s);
        rec.mesh.rotation.y += delta * 0.8;
        rec.mat.emissiveIntensity = isSelected ? 0.95 : matchesCat ? 0.45 : 0.12;
        rec.group.position.y = rec.basePos.y + Math.sin(elapsed * 1.4 + i) * 0.09;
      }

      camera.lookAt(0, 0, 0);
      renderer.render(scene, camera);

      if (isSoftwareGl) {
        scheduleSoftwareFrame(renderer, tick, (id) => {
          frameId = id;
        });
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };

    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      renderer.domElement.removeEventListener('pointermove', handlePointerMove);
      renderer.domElement.removeEventListener('click', handleClick);
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      renderer.domElement.removeEventListener('webglcontextrestored', handleContextRestored);
      window.removeEventListener('resize', handleResize);

      disposableGeos.forEach((g) => g.dispose());
      disposableMats.forEach((m) => m.dispose());
      disposableTextures.forEach((t) => t.dispose());
      envTarget.dispose();
      renderer.dispose();
      if (renderer.domElement.parentElement === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [technologies, reducedMotion, fallbackMode]);

  if (reducedMotion || fallbackMode) {
    return (
      <div className="rounded-2xl border border-slate-800 bg-slate-950 p-6">
        <p className="text-xs font-mono text-cyan-400 mb-4">
          Interactive Technology Constellation
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {technologies.map((tech) => {
            const isSelected = tech.id === selectedTechId;
            return (
              <button
                key={tech.id}
                type="button"
                onClick={() => onSelectTech(tech.id)}
                className={`p-3 rounded-xl border text-left transition-all ${
                  isSelected
                    ? 'bg-slate-800 border-cyan-500 text-white'
                    : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-600'
                }`}
              >
                <div className="font-bold text-sm">{tech.name}</div>
                <div className="text-[11px] text-slate-400 mt-0.5">{tech.category}</div>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-950 overflow-hidden shadow-2xl">
      <div className="px-5 py-3 border-b border-slate-800 flex items-center justify-between text-xs text-slate-400">
        <span className="font-semibold text-cyan-400">Interactive 3D Tech Constellation</span>
        <span>Click any orbiting node to inspect</span>
      </div>
      <div ref={mountRef} className="w-full h-[340px] sm:h-[400px]" />
    </div>
  );
}
