export type TechCategory =
  | 'Frontend & UI'
  | 'Backend & Databases'
  | 'AI & Machine Learning'
  | 'Game & Mobile';

export interface TechnologyItem {
  id: string;
  name: string;
  category: TechCategory;
  summary: string;
  useCases: string[];
  colorHex: string;
}

export const TECH_STACK_MARQUEE: string[] = [
  'React.js',
  'Next.js',
  'Node.js',
  'Java',
  'C++',
  'Unity 3D',
  'Python',
  'OpenAI API',
  'TensorFlow',
  'Firebase',
  'MongoDB',
  'Tailwind CSS',
  'Figma',
];

export const TECHNOLOGIES: TechnologyItem[] = [
  {
    id: 'react',
    name: 'React.js',
    category: 'Frontend & UI',
    summary: 'Component-driven architecture for fast, modular single-page and multi-page web apps.',
    useCases: ['Interactive Dashboards', 'SaaS Portals', '3D Web Experiences'],
    colorHex: '#22d3ee',
  },
  {
    id: 'nextjs',
    name: 'Next.js',
    category: 'Frontend & UI',
    summary: 'Full-stack React framework suited for SEO-friendly web apps and server-rendered pages.',
    useCases: ['Marketing Websites', 'SEO Landing Pages', 'Full-Stack Web Apps'],
    colorHex: '#38bdf8',
  },
  {
    id: 'tailwind',
    name: 'Tailwind CSS',
    category: 'Frontend & UI',
    summary: 'Utility-first styling system for consistent spacing, responsive grids, and dark UI themes.',
    useCases: ['Design Systems', 'Admin Interfaces', 'Rapid Prototyping'],
    colorHex: '#06b6d4',
  },
  {
    id: 'figma',
    name: 'Figma',
    category: 'Frontend & UI',
    summary: 'Collaborative interface design and interactive prototyping prior to frontend engineering.',
    useCases: ['UI Wireframes', 'Clickable Prototypes', 'Component Specs'],
    colorHex: '#facc15',
  },
  {
    id: 'nodejs',
    name: 'Node.js',
    category: 'Backend & Databases',
    summary: 'Event-driven JavaScript runtime for scalable REST APIs and AI proxy backends.',
    useCases: ['API Services', 'Webhook Handlers', 'Real-Time Backends'],
    colorHex: '#4ade80',
  },
  {
    id: 'java',
    name: 'Java',
    category: 'Backend & Databases',
    summary: 'Structured object-oriented backend and Android foundation for reliable admin systems.',
    useCases: ['Secure Admin Panels', 'Enterprise Logic', 'Android Development'],
    colorHex: '#fb923c',
  },
  {
    id: 'firebase',
    name: 'Firebase',
    category: 'Backend & Databases',
    summary: 'Managed authentication, real-time database sync, and cloud backend services for apps.',
    useCases: ['Mobile App Backends', 'Auth Flows', 'Live Data Sync'],
    colorHex: '#f59e0b',
  },
  {
    id: 'mongodb',
    name: 'MongoDB',
    category: 'Backend & Databases',
    summary: 'Flexible document database for evolving product schemas and API-driven applications.',
    useCases: ['Admin Data Stores', 'Content Catalogs', 'User Records'],
    colorHex: '#34d399',
  },
  {
    id: 'python',
    name: 'Python',
    category: 'AI & Machine Learning',
    summary: 'Core scripting and backend language for AI automation, data pipelines, and ML models.',
    useCases: ['AI Orchestration', 'Automation Scripts', 'Model Serving'],
    colorHex: '#60a5fa',
  },
  {
    id: 'openai',
    name: 'OpenAI API',
    category: 'AI & Machine Learning',
    summary: 'Large Language Model integration for conversational agents, summarization, and workflow automation.',
    useCases: ['Custom Chatbots', 'Prompt Pipelines', 'GenAI Marketing'],
    colorHex: '#c084fc',
  },
  {
    id: 'tensorflow',
    name: 'TensorFlow',
    category: 'AI & Machine Learning',
    summary: 'Machine learning framework for training and running custom inference models.',
    useCases: ['Custom ML Models', 'Pattern Classification', 'Predictive Features'],
    colorHex: '#f472b6',
  },
  {
    id: 'unity',
    name: 'Unity 3D',
    category: 'Game & Mobile',
    summary: 'Cross-platform 2D and 3D game engine tailored for responsive mobile and desktop play.',
    useCases: ['Minimal Mobile Games', '3D Prototypes', 'Interactive Physics'],
    colorHex: '#a78bfa',
  },
  {
    id: 'cpp',
    name: 'C++',
    category: 'Game & Mobile',
    summary: 'High-efficiency systems and game programming language for performance-critical loops.',
    useCases: ['Game Mechanics', 'Physics Logic', 'Core Algorithms'],
    colorHex: '#3b82f6',
  },
];

export const TECH_CATEGORIES: TechCategory[] = [
  'Frontend & UI',
  'Backend & Databases',
  'AI & Machine Learning',
  'Game & Mobile',
];
