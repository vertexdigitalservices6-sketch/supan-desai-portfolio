export type PortfolioCategory =
  | 'All'
  | 'Web & Admin'
  | 'AI & GenAI'
  | 'Games'
  | 'UI/UX & SEO'
  | 'Mobile Apps';

export interface PortfolioProject {
  slug: string;
  title: string;
  category: Exclude<PortfolioCategory, 'All'>;
  isDemoPlaceholder: true;
  placeholderNotice: string;
  shortDesc: string;
  fullOverview: string;
  technologies: string[];
  architectureHighlights: string[];
  deliverables: string[];
  relatedServiceSlug: string;
  accentHex: string;
  secondaryHex: string;
}

export const PORTFOLIO_CATEGORIES: PortfolioCategory[] = [
  'All',
  'Web & Admin',
  'AI & GenAI',
  'Games',
  'UI/UX & SEO',
  'Mobile Apps',
];

export const PROJECTS: PortfolioProject[] = [
  {
    slug: 'scalable-react-admin-suite',
    title: 'React & Java Admin Portal Blueprint',
    category: 'Web & Admin',
    isDemoPlaceholder: true,
    placeholderNotice: 'Editable Demo Placeholder — Replace with live project case study',
    shortDesc:
      'Demonstration showcase illustrating modular React dashboards paired with secure Java/Node REST APIs.',
    fullOverview:
      'This editable demo placeholder represents a typical Web & Admin Panel engagement: a responsive React and Tailwind CSS operations interface backed by structured role permissions, searchable tables, and a Java or Node.js API layer.',
    technologies: ['React.js', 'Tailwind CSS', 'Java', 'MongoDB'],
    architectureHighlights: [
      'Component-driven dashboard layout with keyboard-accessible tables',
      'Clean separation between UI state and REST API client services',
      'Ready for deployment on Vercel, Netlify, AWS, or DigitalOcean',
    ],
    deliverables: [
      'Full React frontend source code',
      'Backend API & database schema',
      'Deployment setup and 7-day launch support',
    ],
    relatedServiceSlug: 'web-development',
    accentHex: '#06b6d4',
    secondaryHex: '#3b82f6',
  },
  {
    slug: 'genai-workflow-assistant',
    title: 'Custom AI Chatbot & Workflow Demo',
    category: 'AI & GenAI',
    isDemoPlaceholder: true,
    placeholderNotice: 'Editable Demo Placeholder — Replace with live project case study',
    shortDesc:
      'Demonstration showcase of a prompt-engineered LLM assistant designed to automate user inquiries.',
    fullOverview:
      'This editable demo placeholder illustrates how custom AI Chatbots and Generative AI pipelines are structured using Python, Node.js, and the OpenAI API—connecting conversational interfaces to structured business workflows.',
    technologies: ['OpenAI API', 'Python', 'Node.js', 'React.js'],
    architectureHighlights: [
      'Server-side LLM proxy keeping API keys secure',
      'System prompt guardrails and structured JSON action outputs',
      'Embeddable React chat widget with clear fallback states',
    ],
    deliverables: [
      'Custom prompt templates & Python/Node backend',
      'Responsive web chat interface',
      'Documentation for ongoing prompt tuning',
    ],
    relatedServiceSlug: 'ai-chatbots',
    accentHex: '#a855f7',
    secondaryHex: '#06b6d4',
  },
  {
    slug: 'unity-arcade-physics-demo',
    title: 'Minimalist Unity 3D Mobile Game Concept',
    category: 'Games',
    isDemoPlaceholder: true,
    placeholderNotice: 'Editable Demo Placeholder — Replace with live project case study',
    shortDesc:
      'Demonstration showcase of a lightweight 2D/3D Unity and C++ physics game concept built for mobile FPS.',
    fullOverview:
      'This editable demo placeholder showcases Supan Desai’s approach to minimal mobile games: crisp touch responsiveness, optimized collision and physics loops, and low draw-call geometry tailored for smooth mobile performance.',
    technologies: ['Unity 3D', 'C++', 'Firebase'],
    architectureHighlights: [
      'Object-pooled obstacles and lightweight shaders for steady mobile FPS',
      'Touch-first input handling and clean HUD state machine',
      'Optional leaderboard or cloud save sync via Firebase',
    ],
    deliverables: [
      'Complete Unity 3D / C++ project source',
      'Android APK / Play Store-ready build',
      '100% IP and source code ownership',
    ],
    relatedServiceSlug: 'game-development',
    accentHex: '#22c55e',
    secondaryHex: '#06b6d4',
  },
  {
    slug: 'technical-seo-audit-blueprint',
    title: 'Technical SEO & GenAI Audit Framework',
    category: 'UI/UX & SEO',
    isDemoPlaceholder: true,
    placeholderNotice: 'Editable Demo Placeholder — Replace with live project case study',
    shortDesc:
      'Demonstration showcase of a structured technical SEO audit, competitor teardown, and GenAI content plan.',
    fullOverview:
      'This editable demo placeholder demonstrates the deliverables behind Supan Desai’s Advanced SEO Audit gigs on Fiverr and Osdire—combining technical crawl diagnostics, semantic metadata fixes, and AI-assisted keyword strategy.',
    technologies: ['Next.js', 'OpenAI API', 'Tailwind CSS'],
    architectureHighlights: [
      'Metadata, canonical URL, sitemap.xml, and Schema.org JSON-LD checklist',
      'Competitor keyword gap and content structure breakdown',
      'Core Web Vitals and mobile usability remediation steps',
    ],
    deliverables: [
      'Prioritized technical SEO audit report',
      'Competitor analysis matrix',
      'Actionable metadata & content implementation guide',
    ],
    relatedServiceSlug: 'digital-marketing-seo',
    accentHex: '#ec4899',
    secondaryHex: '#3b82f6',
  },
  {
    slug: 'conversion-ui-ux-system',
    title: 'Conversion-Focused Figma Design System',
    category: 'UI/UX & SEO',
    isDemoPlaceholder: true,
    placeholderNotice: 'Editable Demo Placeholder — Replace with live project case study',
    shortDesc:
      'Demonstration showcase of a dark-mode Figma component library and interactive prototype ready for React.',
    fullOverview:
      'This editable demo placeholder highlights a UI/UX Design workflow in Figma—establishing accessible contrast, typography scales, interactive button states, and modular cards that map directly to Tailwind CSS utilities.',
    technologies: ['Figma', 'Tailwind CSS', 'React.js'],
    architectureHighlights: [
      'Unified color tokens, spacing rules, and responsive breakpoints',
      'Interactive clickable Figma flows for stakeholder review',
      'Clean developer handoff with component state specs',
    ],
    deliverables: [
      'Organized Figma design file & component library',
      'Interactive desktop & mobile prototypes',
      'Optional React + Tailwind implementation',
    ],
    relatedServiceSlug: 'ui-ux-design',
    accentHex: '#eab308',
    secondaryHex: '#06b6d4',
  },
  {
    slug: 'android-companion-admin-sync',
    title: 'AI Android App & Admin Panel Concept',
    category: 'Mobile Apps',
    isDemoPlaceholder: true,
    placeholderNotice: 'Editable Demo Placeholder — Replace with live project case study',
    shortDesc:
      'Demonstration showcase pairing a modern Android application with a real-time Firebase web admin panel.',
    fullOverview:
      'This editable demo placeholder represents a complete Mobile App + Admin Panel architecture: an Android or React Native client synced in real time with Firebase and managed through a dedicated React admin dashboard.',
    technologies: ['Java', 'React.js', 'Firebase', 'OpenAI API'],
    architectureHighlights: [
      'Real-time data synchronization between mobile client and web admin',
      'Optional AI assistant or smart automation endpoints',
      'Play Store release checklist and responsive screen testing',
    ],
    deliverables: [
      'Android / React Native app source code',
      'Connected web Admin Panel',
      'Firebase configuration & Play Store launch support',
    ],
    relatedServiceSlug: 'app-development',
    accentHex: '#3b82f6',
    secondaryHex: '#22d3ee',
  },
];

export function getProjectBySlug(slug?: string): PortfolioProject | undefined {
  return PROJECTS.find((p) => p.slug === slug);
}
