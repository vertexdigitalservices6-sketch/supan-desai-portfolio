export interface MarketplaceOffer {
  id: string;
  platform: 'Fiverr' | 'Osdire';
  badge: string;
  title: string;
  description: string;
  url: string;
  highlights: string[];
  relatedServiceSlug: string;
}

export const OFFERS: MarketplaceOffer[] = [
  {
    id: 'fiverr-web-ai',
    platform: 'Fiverr',
    badge: 'fi',
    title: 'Web & AI Development',
    description: 'Professional Web Development & AI Integration Services.',
    url: 'https://www.fiverr.com/s/8z32qPE',
    highlights: [
      'React.js & Next.js responsive web apps',
      'AI Chatbots & OpenAI API workflow integration',
      'Clean source code & deployment assistance',
    ],
    relatedServiceSlug: 'web-development',
  },
  {
    id: 'fiverr-seo-audit',
    platform: 'Fiverr',
    badge: 'fi',
    title: 'Advanced SEO Audit',
    description: 'Deep competitor analysis, keyword strategy, and technical SEO.',
    url: 'https://www.fiverr.com/s/38x31lr',
    highlights: [
      'Technical crawl & on-page optimization checklist',
      'Competitor benchmarking & keyword strategy',
      'Actionable fixes for better search visibility',
    ],
    relatedServiceSlug: 'digital-marketing-seo',
  },
  {
    id: 'osdire-apps-games',
    platform: 'Osdire',
    badge: 'Os',
    title: 'Apps & Games',
    description: 'Modern Android Apps with Admin Panels & Minimal Games.',
    url: 'https://osdire.com/supan_desai/offer/i-will-create-ai-modern-android-apps-with-admin-panel-and-minimal-games',
    highlights: [
      'AI-enhanced modern Android applications',
      'Connected web Admin Panel for full control',
      'Minimalist 2D/3D Unity & C++ mobile games',
    ],
    relatedServiceSlug: 'app-development',
  },
  {
    id: 'osdire-seo-audit',
    platform: 'Osdire',
    badge: 'Os',
    title: 'Advanced SEO Audit',
    description: 'In-depth competitor analysis and SEO strategy report.',
    url: 'https://osdire.com/supan_desai/offer/i-will-provide-advanced-seo-audit-and-competitor-analysis-report',
    highlights: [
      'Detailed competitor teardown report',
      'Technical metadata & performance review',
      'GenAI-supported growth recommendations',
    ],
    relatedServiceSlug: 'digital-marketing-seo',
  },
];
