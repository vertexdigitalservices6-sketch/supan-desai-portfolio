export type ServiceIconKey =
  | 'code'
  | 'bot'
  | 'gamepad'
  | 'trending'
  | 'layout'
  | 'smartphone';

export interface ServiceWorkflowStep {
  step: string;
  title: string;
  description: string;
}

export interface ServiceItem {
  slug: string;
  title: string;
  navLabel: string;
  desc: string;
  tags: string[];
  highlight: string;
  iconKey: ServiceIconKey;
  accentClass: string;
  borderHoverClass: string;
  glowColor: string;
  overview: string;
  features: string[];
  technologies: string[];
  benefits: string[];
  workflow: ServiceWorkflowStep[];
  primaryOfferUrl: string;
  primaryOfferLabel: string;
}

export const SERVICES: ServiceItem[] = [
  {
    slug: 'web-development',
    title: 'Web & Admin Panels',
    navLabel: 'Web Development',
    desc: 'High-performance React applications and secure Java-based admin dashboards.',
    tags: ['React', 'HTML5', 'Java', 'Tailwind'],
    highlight: 'Scalable Tools',
    iconKey: 'code',
    accentClass: 'text-cyan-400',
    borderHoverClass: 'hover:border-cyan-500/50',
    glowColor: 'rgba(6, 182, 212, 0.25)',
    overview:
      'From responsive marketing websites to full-featured SaaS portals and Java-backed administrative dashboards, every web architecture is engineered for clean maintainability, fast load speeds, and reliable deployment.',
    features: [
      'Modular React.js & Next.js single-page or multi-page interfaces',
      'Role-based Admin Panels with structured data tables and controls',
      'REST API integration with Node.js, Java, MongoDB, or Firebase',
      'Responsive Tailwind CSS layouts tuned for desktop and mobile',
    ],
    technologies: ['React.js', 'Next.js', 'Node.js', 'Java', 'Tailwind CSS', 'MongoDB', 'Firebase'],
    benefits: [
      '100% ownership of clean, documented source code upon completion',
      'Deployment support on Vercel, Netlify, AWS, or DigitalOcean',
      'Starting packages available from ₹1,000 for focused tasks',
    ],
    workflow: [
      {
        step: '01',
        title: 'Scope & Architecture',
        description: 'Define user roles, data flows, pages, and required integrations upfront.',
      },
      {
        step: '02',
        title: 'UI & Backend Build',
        description: 'Develop responsive frontend modules connected to secure backend APIs.',
      },
      {
        step: '03',
        title: 'Testing & Launch',
        description: 'Cross-device QA, hosting setup, and 7 days of post-launch bug-fix support.',
      },
    ],
    primaryOfferUrl: 'https://www.fiverr.com/s/8z32qPE',
    primaryOfferLabel: 'Order Web Dev on Fiverr',
  },
  {
    slug: 'ai-chatbots',
    title: 'AI Chatbots & GenAI',
    navLabel: 'AI Chatbots & GenAI',
    desc: 'Custom AI agents and prompt engineering solutions to automate workflows.',
    tags: ['OpenAI API', 'Python', 'LLMs'],
    highlight: 'Reduce Costs',
    iconKey: 'bot',
    accentClass: 'text-purple-400',
    borderHoverClass: 'hover:border-purple-500/50',
    glowColor: 'rgba(192, 132, 252, 0.25)',
    overview:
      'Practical Generative AI integrations built to handle real business workflows—from customer support assistants and document Q&A bots to automated content and prompt pipelines powered by Python and LLM APIs.',
    features: [
      'Custom conversational chatbots embedded into web or mobile products',
      'Structured prompt engineering and tool-calling workflows',
      'Python & Node.js orchestration with OpenAI API and TensorFlow',
      'Guardrailed responses tailored to your product knowledge base',
    ],
    technologies: ['Python', 'OpenAI API', 'TensorFlow', 'Node.js', 'React.js'],
    benefits: [
      'Automate repetitive support and intake workflows',
      'Seamless API integration into existing React or admin dashboards',
      'Optional extended support for prompt and model fine-tuning',
    ],
    workflow: [
      {
        step: '01',
        title: 'Use-Case Mapping',
        description: 'Identify high-impact automation targets and expected assistant behaviors.',
      },
      {
        step: '02',
        title: 'Prompt & API Engineering',
        description: 'Build reliable server-side LLM endpoints with structured output handling.',
      },
      {
        step: '03',
        title: 'Integration & Tuning',
        description: 'Embed into your interface and verify response accuracy across edge cases.',
      },
    ],
    primaryOfferUrl: 'https://www.fiverr.com/s/8z32qPE',
    primaryOfferLabel: 'Book AI Integration on Fiverr',
  },
  {
    slug: 'game-development',
    title: 'Game Development',
    navLabel: 'Game Development',
    desc: 'Immersive 2D/3D games using C++ and Unity. Optimized for mobile.',
    tags: ['C++', 'Unity', 'Physics', 'Mobile'],
    highlight: 'High FPS',
    iconKey: 'gamepad',
    accentClass: 'text-green-400',
    borderHoverClass: 'hover:border-green-500/50',
    glowColor: 'rgba(74, 222, 128, 0.25)',
    overview:
      'Engaging 2D and 3D games engineered with Unity 3D and C++. Built with responsive touch or desktop controls, tuned physics loops, and lightweight asset pipelines for smooth frame rates on mobile devices.',
    features: [
      '2D & 3D gameplay mechanics, physics, and collision systems',
      'Minimalist arcade and casual mobile game builds in Unity 3D',
      'Performance-conscious C++ and C# scripting for steady FPS',
      'Clean UI menus, score systems, and mobile store readiness',
    ],
    technologies: ['Unity 3D', 'C++', 'Firebase'],
    benefits: [
      'Full source code and project files delivered at completion',
      'Tuned specifically for responsive mobile play and battery efficiency',
      'Available as standalone minimal games or bundled with Android apps',
    ],
    workflow: [
      {
        step: '01',
        title: 'Core Loop Prototype',
        description: 'Validate player movement, camera feel, and game rules early.',
      },
      {
        step: '02',
        title: 'Systems & Polish',
        description: 'Implement levels, physics tuning, audio cues, and responsive HUD.',
      },
      {
        step: '03',
        title: 'Build & Optimization',
        description: 'Profile frame times on target devices and package release builds.',
      },
    ],
    primaryOfferUrl:
      'https://osdire.com/supan_desai/offer/i-will-create-ai-modern-android-apps-with-admin-panel-and-minimal-games',
    primaryOfferLabel: 'View Games Offer on Osdire',
  },
  {
    slug: 'digital-marketing-seo',
    title: 'Digital Marketing & SEO',
    navLabel: 'Digital Marketing & SEO',
    desc: 'Data-driven marketing strategies supercharged with Generative AI.',
    tags: ['SEO Audit', 'GenAI Marketing'],
    highlight: 'Rank #1',
    iconKey: 'trending',
    accentClass: 'text-pink-400',
    borderHoverClass: 'hover:border-pink-500/50',
    glowColor: 'rgba(244, 114, 182, 0.25)',
    overview:
      'Comprehensive technical SEO audits, competitor analysis reports, and GenAI-assisted content strategies designed to eliminate indexing bottlenecks and sharpen your organic search visibility.',
    features: [
      'Deep technical SEO audit covering metadata, speed, and crawlability',
      'Competitor analysis and actionable keyword opportunity mapping',
      'Structured data, Open Graph, and semantic HTML recommendations',
      'Generative AI marketing workflows for consistent campaign execution',
    ],
    technologies: ['OpenAI API', 'Next.js', 'HTML5'],
    benefits: [
      'Clear, prioritized action checklist rather than vague summaries',
      'Direct implementation options for React/Next.js or static sites',
      'Verified marketplace packages available on both Fiverr and Osdire',
    ],
    workflow: [
      {
        step: '01',
        title: 'Technical Crawl & Audit',
        description: 'Inspect site architecture, meta tags, Core Web Vitals, and indexation.',
      },
      {
        step: '02',
        title: 'Competitor Benchmarking',
        description: 'Analyze competing domains and uncover high-intent keyword gaps.',
      },
      {
        step: '03',
        title: 'Actionable Roadmap',
        description: 'Deliver a prioritized SEO & GenAI growth report ready for execution.',
      },
    ],
    primaryOfferUrl: 'https://www.fiverr.com/s/38x31lr',
    primaryOfferLabel: 'Order SEO Audit on Fiverr',
  },
  {
    slug: 'ui-ux-design',
    title: 'UI/UX Design',
    navLabel: 'UI/UX Design',
    desc: 'Modern, accessible, and conversion-focused interfaces.',
    tags: ['Figma', 'Prototyping'],
    highlight: 'User First',
    iconKey: 'layout',
    accentClass: 'text-yellow-400',
    borderHoverClass: 'hover:border-yellow-500/50',
    glowColor: 'rgba(250, 204, 21, 0.25)',
    overview:
      'Clean, conversion-focused user interfaces crafted in Figma with developer-ready component systems, clear visual hierarchy, and responsive layouts that transition smoothly into React and Tailwind CSS code.',
    features: [
      'Interactive Figma wireframes and clickable user-flow prototypes',
      'Consistent typography, spacing, and dark/light design tokens',
      'Accessible component states for web apps, dashboards, and mobile',
      'Direct design-to-Tailwind handoff with zero guesswork',
    ],
    technologies: ['Figma', 'Tailwind CSS', 'React.js'],
    benefits: [
      'Eliminate engineering rework with crystal-clear screen specs',
      'Focused on usability, readability, and clear calls to action',
      'Can be paired seamlessly with full-stack development',
    ],
    workflow: [
      {
        step: '01',
        title: 'User Flow & Wireframes',
        description: 'Map core journeys and screen hierarchy before visual styling.',
      },
      {
        step: '02',
        title: 'Visual System & Prototype',
        description: 'Design high-contrast components and interactive Figma flows.',
      },
      {
        step: '03',
        title: 'Developer Handoff',
        description: 'Deliver organized Figma frames ready for React/mobile build.',
      },
    ],
    primaryOfferUrl: 'https://www.fiverr.com/s/8z32qPE',
    primaryOfferLabel: 'Discuss UI/UX Project',
  },
  {
    slug: 'app-development',
    title: 'App Development',
    navLabel: 'App Development',
    desc: 'Native and cross-platform mobile apps integrated with powerful backends.',
    tags: ['Android', 'React Native'],
    highlight: 'Seamless UX',
    iconKey: 'smartphone',
    accentClass: 'text-blue-400',
    borderHoverClass: 'hover:border-blue-500/50',
    glowColor: 'rgba(96, 165, 250, 0.25)',
    overview:
      'Modern Android and cross-platform React Native applications backed by Firebase, MongoDB, or custom Node.js/Java APIs—often paired with matching web admin panels for complete operational control.',
    features: [
      'Native Android and React Native cross-platform app development',
      'Connected web admin panels for content, user, and data management',
      'AI-powered features, real-time sync with Firebase, and push flows',
      'Google Play Store packaging and release deployment assistance',
    ],
    technologies: ['Java', 'React.js', 'Firebase', 'MongoDB', 'Node.js', 'OpenAI API'],
    benefits: [
      'Unified mobile app + admin panel architecture from a single developer',
      '100% source code ownership and Play Store publishing guidance',
      'Available directly through verified Osdire marketplace offers',
    ],
    workflow: [
      {
        step: '01',
        title: 'App & Backend Blueprint',
        description: 'Align on mobile screens, offline needs, and admin panel controls.',
      },
      {
        step: '02',
        title: 'Mobile & API Development',
        description: 'Build responsive mobile views synced with Firebase or custom APIs.',
      },
      {
        step: '03',
        title: 'Device QA & Store Launch',
        description: 'Test on physical Android screen sizes and assist with Play Store release.',
      },
    ],
    primaryOfferUrl:
      'https://osdire.com/supan_desai/offer/i-will-create-ai-modern-android-apps-with-admin-panel-and-minimal-games',
    primaryOfferLabel: 'Order Android App on Osdire',
  },
];

export function getServiceBySlug(slug?: string): ServiceItem | undefined {
  return SERVICES.find((s) => s.slug === slug);
}
