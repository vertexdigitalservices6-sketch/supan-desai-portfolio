export interface FAQItem {
  question: string;
  answer: string;
  category: 'Pricing' | 'Ownership' | 'Deployment' | 'Support';
}

export const FAQS: FAQItem[] = [
  {
    question: 'What is your hourly rate vs fixed project price?',
    answer:
      "I mostly work on a fixed-project basis starting from ₹1,000 for small tasks. This ensures you know exactly what you're paying upfront with no hidden costs. For long-term maintenance, I offer monthly retainers.",
    category: 'Pricing',
  },
  {
    question: 'Do you provide source code upon completion?',
    answer:
      'Yes, absolutely. For all development projects (Web, Games, Apps), you receive 100% ownership of the source code and intellectual property upon final payment.',
    category: 'Ownership',
  },
  {
    question: 'Can you help with hosting and deployment?',
    answer:
      "Yes! I don't just build; I launch. I can set up your React apps on Vercel/Netlify, deploy Admin Panels on AWS/DigitalOcean, and publish Apps to the Play Store.",
    category: 'Deployment',
  },
  {
    question: 'Do you offer post-launch support?',
    answer:
      'Every project comes with 7 days of free bug-fixing support. Extended maintenance packages are available if you need ongoing updates and AI model fine-tuning.',
    category: 'Support',
  },
];
