import { Link } from 'react-router-dom';
import { PROFILE } from '../data/profile';

interface LogoProps {
  compact?: boolean;
  onClick?: () => void;
}

export default function Logo({ compact = false, onClick }: LogoProps) {
  return (
    <Link
      to="/"
      onClick={onClick}
      className="flex items-center gap-2.5 group cursor-pointer shrink-0 whitespace-nowrap"
      aria-label={`${PROFILE.name} - Home`}
    >
      <div className="relative w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center transform group-hover:rotate-3 transition-transform duration-300 shadow-lg shadow-cyan-500/20">
        <span className="text-white font-bold text-xl font-mono">
          {PROFILE.brandInitials}
        </span>
        <span
          className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-400 rounded-full border-2 border-slate-900 animate-pulse"
          aria-hidden="true"
        />
      </div>
      {!compact && (
        <div className="flex flex-col">
          <span className="font-bold text-lg leading-none tracking-tight text-white group-hover:text-cyan-400 transition-colors">
            {PROFILE.name}
          </span>
          <span className="text-[10px] text-slate-400 font-mono tracking-wider uppercase mt-0.5">
            {PROFILE.shortRole}
          </span>
        </div>
      )}
    </Link>
  );
}
