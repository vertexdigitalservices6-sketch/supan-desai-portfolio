import { Component, type ErrorInfo, type ReactNode, Suspense } from 'react';

interface Scene3DProps {
  children: ReactNode;
  fallback?: ReactNode;
  loadingLabel?: string;
  className?: string;
}

interface ErrorBoundaryState {
  hasError: boolean;
}

class SceneErrorBoundary extends Component<
  { children: ReactNode; fallback: ReactNode },
  ErrorBoundaryState
> {
  state: ErrorBoundaryState = { hasError: false };

  static getDerivedStateFromError(): ErrorBoundaryState {
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.warn('3D scene fallback activated:', error.message, info.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback;
    }
    return this.props.children;
  }
}

export default function Scene3D({
  children,
  fallback,
  loadingLabel = 'Initializing 3D Experience...',
  className = '',
}: Scene3DProps) {
  const defaultFallback = fallback ?? (
    <div className="w-full h-full min-h-[260px] rounded-2xl border border-slate-800 bg-slate-950/90 flex items-center justify-center p-6 text-center">
      <div className="space-y-2">
        <div className="w-10 h-10 mx-auto rounded-lg bg-gradient-to-br from-cyan-500/20 to-blue-600/20 border border-cyan-500/30 flex items-center justify-center font-mono text-cyan-400 font-bold">
          3D
        </div>
        <p className="text-sm text-slate-400">Interactive 3D view ready on WebGL devices.</p>
      </div>
    </div>
  );

  const loadingView = (
    <div className="w-full h-full min-h-[260px] rounded-2xl border border-slate-800/80 bg-slate-950/80 flex items-center justify-center p-6">
      <div className="flex items-center gap-3 text-xs font-mono text-cyan-400">
        <span className="w-4 h-4 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin" />
        <span>{loadingLabel}</span>
      </div>
    </div>
  );

  return (
    <div className={className}>
      <SceneErrorBoundary fallback={defaultFallback}>
        <Suspense fallback={loadingView}>{children}</Suspense>
      </SceneErrorBoundary>
    </div>
  );
}
