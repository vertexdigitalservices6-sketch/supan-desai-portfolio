import { useState } from 'react';
import { ChevronRight, X } from 'lucide-react';
import type { FAQItem } from '../data/faqs';

interface FAQAccordionProps {
  items: FAQItem[];
  defaultOpenIndex?: number | null;
}

export default function FAQAccordion({
  items,
  defaultOpenIndex = null,
}: FAQAccordionProps) {
  const [openFaq, setOpenFaq] = useState<number | null>(defaultOpenIndex);

  return (
    <div className="space-y-4">
      {items.map((faq, index) => {
        const isOpen = openFaq === index;
        return (
          <div
            key={faq.question}
            className="border border-slate-700 rounded-xl bg-slate-800/50 overflow-hidden"
          >
            <button
              type="button"
              aria-expanded={isOpen}
              className="w-full text-left p-6 flex justify-between items-center gap-4 hover:bg-slate-800 transition-colors"
              onClick={() => setOpenFaq(isOpen ? null : index)}
            >
              <span className="font-bold text-slate-200">{faq.question}</span>
              {isOpen ? (
                <X size={20} className="text-cyan-500 shrink-0" />
              ) : (
                <ChevronRight size={20} className="text-slate-500 shrink-0" />
              )}
            </button>
            {isOpen && (
              <div className="p-6 pt-0 text-slate-400 text-sm leading-relaxed bg-slate-800/50 border-t border-slate-700/50">
                <div className="pt-4">{faq.answer}</div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
