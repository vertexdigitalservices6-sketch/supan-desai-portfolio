import { Bot, Code, Gamepad2, Layout, Smartphone, TrendingUp } from 'lucide-react';
import type { ServiceIconKey } from '../data/services';

interface ServiceIconProps {
  iconKey: ServiceIconKey;
  size?: number;
  className?: string;
}

export default function ServiceIcon({
  iconKey,
  size = 32,
  className = '',
}: ServiceIconProps) {
  switch (iconKey) {
    case 'code':
      return <Code size={size} className={`text-cyan-400 ${className}`} />;
    case 'bot':
      return <Bot size={size} className={`text-purple-400 ${className}`} />;
    case 'gamepad':
      return <Gamepad2 size={size} className={`text-green-400 ${className}`} />;
    case 'trending':
      return <TrendingUp size={size} className={`text-pink-400 ${className}`} />;
    case 'layout':
      return <Layout size={size} className={`text-yellow-400 ${className}`} />;
    case 'smartphone':
      return <Smartphone size={size} className={`text-blue-400 ${className}`} />;
  }
}
