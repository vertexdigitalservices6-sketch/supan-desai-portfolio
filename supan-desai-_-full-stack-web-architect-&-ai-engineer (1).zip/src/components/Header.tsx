import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { ChevronDown, Menu, X } from 'lucide-react';
import Logo from './Logo';
import { SERVICES } from '../data/services';

const NAV_LINKS = [
  { to: '/', label: 'Home' },
  { to: '/about', label: 'About' },
  { to: '/technology', label: 'Technology' },
  { to: '/portfolio', label: 'Portfolio' },
  { to: '/offers', label: 'Offers' },
  { to: '/faq', label: 'FAQ' },
  { to: '/contact', label: 'Contact' },
];

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);
  const [isMobileServicesOpen, setIsMobileServicesOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const dropdownRef = useRef<HTMLDivElement | null>(null);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 36);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Close menus on route change
  useEffect(() => {
    setIsMenuOpen(false);
    setIsServicesOpen(false);
    setIsMobileServicesOpen(false);
  }, [location.pathname]);

  // Close dropdown on outside click or Escape
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsServicesOpen(false);
      }
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsServicesOpen(false);
        setIsMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  const isServicesActive = location.pathname.startsWith('/services');
  const isHomeTop = location.pathname === '/' && !scrolled && !isMenuOpen;

  return (
    <header
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        isHomeTop
          ? 'bg-transparent py-5'
          : 'bg-slate-900/95 backdrop-blur-md border-b border-slate-800 py-3 shadow-lg shadow-slate-950/30'
      }`}
    >
      <div className="container mx-auto px-6 flex justify-between items-center gap-4">
        <Logo onClick={() => setIsMenuOpen(false)} />

        {/* Desktop Navigation */}
        <nav
          aria-label="Primary navigation"
          className="hidden lg:flex items-center gap-6 text-sm font-medium"
        >
          <NavLink
            to="/"
            end
            className={({ isActive }) =>
              `uppercase tracking-wide text-xs transition-colors whitespace-nowrap shrink-0 ${
                isActive ? 'text-cyan-400 font-semibold' : 'text-slate-400 hover:text-cyan-400'
              }`
            }
          >
            Home
          </NavLink>

          <NavLink
            to="/about"
            className={({ isActive }) =>
              `uppercase tracking-wide text-xs transition-colors whitespace-nowrap shrink-0 ${
                isActive ? 'text-cyan-400 font-semibold' : 'text-slate-400 hover:text-cyan-400'
              }`
            }
          >
            About
          </NavLink>

          {/* Services Dropdown */}
          <div
            ref={dropdownRef}
            className="relative"
            onMouseEnter={() => setIsServicesOpen(true)}
            onMouseLeave={() => setIsServicesOpen(false)}
          >
            <button
              type="button"
              onClick={() => setIsServicesOpen((prev) => !prev)}
              aria-expanded={isServicesOpen}
              aria-haspopup="true"
              className={`inline-flex items-center gap-1 uppercase tracking-wide text-xs transition-colors whitespace-nowrap shrink-0 py-2 ${
                isServicesActive
                  ? 'text-cyan-400 font-semibold'
                  : 'text-slate-400 hover:text-cyan-400'
              }`}
            >
              <span>Services</span>
              <ChevronDown
                size={14}
                className={`transition-transform duration-200 ${
                  isServicesOpen ? 'rotate-180 text-cyan-400' : ''
                }`}
              />
            </button>

            {isServicesOpen && (
              <div className="absolute left-0 top-full pt-1 w-64 z-50">
                <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl p-2 space-y-1">
                  <NavLink
                    to="/services"
                    end
                    className={({ isActive }) =>
                      `block px-3.5 py-2 rounded-lg text-xs font-semibold uppercase tracking-wide transition-colors ${
                        isActive
                          ? 'bg-cyan-500/15 text-cyan-400'
                          : 'text-slate-200 hover:bg-slate-800 hover:text-cyan-400'
                      }`
                    }
                  >
                    All Services Overview
                  </NavLink>
                  <div className="border-t border-slate-800 my-1" />
                  {SERVICES.map((service) => (
                    <NavLink
                      key={service.slug}
                      to={`/services/${service.slug}`}
                      className={({ isActive }) =>
                        `block px-3.5 py-2 rounded-lg text-xs transition-colors ${
                          isActive
                            ? 'bg-cyan-500/15 text-cyan-400 font-semibold'
                            : 'text-slate-300 hover:bg-slate-800 hover:text-cyan-400'
                        }`
                      }
                    >
                      {service.navLabel}
                    </NavLink>
                  ))}
                </div>
              </div>
            )}
          </div>

          {NAV_LINKS.slice(2).map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) =>
                `uppercase tracking-wide text-xs transition-colors whitespace-nowrap shrink-0 ${
                  isActive ? 'text-cyan-400 font-semibold' : 'text-slate-400 hover:text-cyan-400'
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}

          <Link
            to="/contact"
            className="px-5 py-2.5 bg-cyan-500 hover:bg-cyan-600 text-white font-bold rounded-lg transition-all transform hover:scale-105 shadow-lg shadow-cyan-500/20 text-xs uppercase tracking-wide whitespace-nowrap shrink-0"
          >
            Hire Me
          </Link>
        </nav>

        {/* Mobile Menu Toggle */}
        <button
          type="button"
          aria-label={isMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
          aria-expanded={isMenuOpen}
          className="lg:hidden text-slate-300 hover:text-white p-2 rounded-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
          onClick={() => setIsMenuOpen((prev) => !prev)}
        >
          {isMenuOpen ? <X size={26} /> : <Menu size={26} />}
        </button>
      </div>

      {/* Mobile Navigation Drawer */}
      {isMenuOpen && (
        <div className="lg:hidden absolute top-full left-0 w-full bg-slate-900 border-b border-slate-700 p-6 flex flex-col space-y-2 shadow-2xl max-h-[82vh] overflow-y-auto">
          <NavLink
            to="/"
            end
            className={({ isActive }) =>
              `py-2.5 px-2 text-base border-b border-slate-800 transition-colors ${
                isActive ? 'text-cyan-400 font-semibold' : 'text-slate-300 hover:text-cyan-400'
              }`
            }
          >
            Home
          </NavLink>
          <NavLink
            to="/about"
            className={({ isActive }) =>
              `py-2.5 px-2 text-base border-b border-slate-800 transition-colors ${
                isActive ? 'text-cyan-400 font-semibold' : 'text-slate-300 hover:text-cyan-400'
              }`
            }
          >
            About
          </NavLink>

          {/* Mobile Services Accordion */}
          <div className="border-b border-slate-800 py-1">
            <button
              type="button"
              onClick={() => setIsMobileServicesOpen((prev) => !prev)}
              aria-expanded={isMobileServicesOpen}
              className={`w-full flex items-center justify-between py-2 px-2 text-base transition-colors ${
                isServicesActive ? 'text-cyan-400 font-semibold' : 'text-slate-300'
              }`}
            >
              <span>Services</span>
              <ChevronDown
                size={18}
                className={`transition-transform ${isMobileServicesOpen ? 'rotate-180' : ''}`}
              />
            </button>
            {isMobileServicesOpen && (
              <div className="pl-4 pb-2 flex flex-col space-y-1.5">
                <NavLink
                  to="/services"
                  end
                  className={({ isActive }) =>
                    `py-1.5 text-sm ${
                      isActive ? 'text-cyan-400 font-semibold' : 'text-slate-400 hover:text-cyan-400'
                    }`
                  }
                >
                  All Services
                </NavLink>
                {SERVICES.map((service) => (
                  <NavLink
                    key={service.slug}
                    to={`/services/${service.slug}`}
                    className={({ isActive }) =>
                      `py-1.5 text-sm ${
                        isActive ? 'text-cyan-400 font-semibold' : 'text-slate-400 hover:text-cyan-400'
                      }`
                    }
                  >
                    {service.navLabel}
                  </NavLink>
                ))}
              </div>
            )}
          </div>

          {NAV_LINKS.slice(2).map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) =>
                `py-2.5 px-2 text-base border-b border-slate-800 transition-colors ${
                  isActive ? 'text-cyan-400 font-semibold' : 'text-slate-300 hover:text-cyan-400'
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}

          <div className="pt-3">
            <Link
              to="/contact"
              className="block w-full text-center px-5 py-3 bg-cyan-500 hover:bg-cyan-600 text-white font-bold rounded-lg transition-colors text-sm uppercase tracking-wide"
            >
              Hire Me
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
