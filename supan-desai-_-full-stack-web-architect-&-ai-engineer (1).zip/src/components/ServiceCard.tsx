import { useState, type MouseEvent } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import type { ServiceItem } from '../data/services';
import ServiceIcon from './ServiceIcon';
import { useReducedMotion } from '../hooks/useReducedMotion';

interface ServiceCardProps {
  service: ServiceItem;
  showDetailsLink?: boolean;
}

export default function ServiceCard({
  service,
  showDetailsLink = true,
}: ServiceCardProps) {
  const reducedMotion = useReducedMotion();
  const [tilt, setTilt] = useState({ rotateX: 0, rotateY: 0, active: false });

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    if (reducedMotion) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setTilt({
      rotateX: Number((-y * 9).toFixed(2)),
      rotateY: Number((x * 9).toFixed(2)),
      active: true,
    });
  };

  const handleMouseLeave = () => {
    setTilt({ rotateX: 0, rotateY: 0, active: false });
  };

  return (
    <div
      className="perspective-1000 h-full"
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
    >
      <Link
        to={`/services/${service.slug}`}
        style={{
          transform: reducedMotion
            ? undefined
            : `rotateX(${tilt.rotateX}deg) rotateY(${tilt.rotateY}deg) ${
                tilt.active ? 'translateY(-4px)' : 'translateY(0px)'
              }`,
          boxShadow: tilt.active
            ? `0 20px 35px -15px rgba(2, 6, 23, 0.85), 0 0 24px -6px ${service.glowColor}`
            : undefined,
        }}
        className={`flex flex-col h-full bg-slate-800/50 border border-slate-700/50 p-8 rounded-2xl hover:bg-slate-800 ${service.borderHoverClass} transition-all duration-200 group will-change-transform`}
      >
        <div className="mb-6 flex justify-between items-start">
          <div className="p-3 bg-slate-900 rounded-lg text-white group-hover:scale-110 transition-transform duration-300 border border-slate-700 shadow-inner">
            <ServiceIcon iconKey={service.iconKey} size={32} />
          </div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 border border-slate-700 px-2 py-1 rounded">
            {service.highlight}
          </span>
        </div>

        <h3 className="text-xl font-bold mb-3 text-white group-hover:text-cyan-400 transition-colors">
          {service.title}
        </h3>
        <p className="text-slate-400 mb-6 text-sm leading-relaxed flex-1">
          {service.desc}
        </p>

        <div className="flex flex-wrap gap-2 mb-5">
          {service.tags.map((tag) => (
            <span
              key={tag}
              className="text-xs px-2 py-1 bg-slate-900 rounded text-slate-400 font-mono border border-slate-800"
            >
              {tag}
            </span>
          ))}
        </div>

        {showDetailsLink && (
          <div className="pt-4 border-t border-slate-700/50 flex items-center justify-between text-xs font-semibold text-cyan-400">
            <span>Explore Service</span>
            <ArrowRight
              size={15}
              className="group-hover:translate-x-1 transition-transform"
            />
          </div>
        )}
      </Link>
    </div>
  );
}
