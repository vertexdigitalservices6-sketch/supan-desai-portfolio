import { Link } from 'react-router-dom';
import { ArrowRight, Phone } from 'lucide-react';
import { PROFILE } from '../data/profile';

interface CTAProps {
  title?: string;
  description?: string;
  primaryLabel?: string;
  primaryTo?: string;
}

export default function CTA({
  title = 'Ready to Launch Your Next Project?',
  description = `Packages start from ${PROFILE.startingPrice} with 100% source code ownership and 7 days of free post-launch bug-fixing support.`,
  primaryLabel = 'Start a Project',
  primaryTo = '/contact',
}: CTAProps) {
  return (
    <section className="py-16 bg-slate-950 border-t border-slate-800/80">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto bg-slate-800/80 border border-slate-700 rounded-3xl p-8 md:p-12 text-center shadow-2xl">
          <h2 className="text-2xl md:text-4xl font-bold text-white mb-4">{title}</h2>
          <p className="text-slate-400 max-w-2xl mx-auto mb-8 text-sm md:text-base leading-relaxed">
            {description}
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to={primaryTo}
              className="w-full sm:w-auto px-8 py-3.5 bg-cyan-500 hover:bg-cyan-600 text-white font-bold rounded-lg transition-all shadow-lg shadow-cyan-500/25 inline-flex items-center justify-center gap-2 group"
            >
              <span>{primaryLabel}</span>
              <ArrowRight
                size={18}
                className="group-hover:translate-x-1 transition-transform"
              />
            </Link>
            <a
              href={PROFILE.phoneHref}
              className="w-full sm:w-auto px-8 py-3.5 bg-slate-900 hover:bg-slate-700 border border-slate-700 text-white font-bold rounded-lg transition-all inline-flex items-center justify-center gap-2"
            >
              <Phone size={18} className="text-green-400" />
              <span>{PROFILE.phoneDisplay}</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
