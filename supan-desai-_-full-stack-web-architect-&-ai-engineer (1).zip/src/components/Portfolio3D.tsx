import { lazy } from 'react';
import Scene3D from './Scene3D';
import type { PortfolioProject } from '../data/projects';

const LazyPortfolioScene = lazy(() => import('../scenes/PortfolioScene'));

interface Portfolio3DProps {
  projects: PortfolioProject[];
  selectedIndex: number;
  onSelectIndex: (index: number) => void;
  onInspectProject: (slug: string) => void;
}

export default function Portfolio3D(props: Portfolio3DProps) {
  return (
    <Scene3D loadingLabel="Preparing 3D Exhibition Gallery...">
      <LazyPortfolioScene {...props} />
    </Scene3D>
  );
}
