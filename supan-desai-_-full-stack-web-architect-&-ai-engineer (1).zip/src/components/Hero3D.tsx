import { lazy } from 'react';
import Scene3D from './Scene3D';

const LazyHeroScene = lazy(() => import('../scenes/HeroScene'));

export default function Hero3D() {
  return (
    <Scene3D
      loadingLabel="Loading 3D Wireframe Sphere..."
      className="absolute inset-0 z-0 opacity-85 pointer-events-none"
      fallback={
        <div
          className="absolute inset-0 flex items-center justify-center pointer-events-none"
          aria-hidden="true"
        >
          <div className="w-80 h-80 md:w-[440px] md:h-[440px] rounded-full border border-cyan-500/20 bg-gradient-to-br from-cyan-500/10 to-blue-600/10" />
        </div>
      }
    >
      <LazyHeroScene />
    </Scene3D>
  );
}
