import { Link } from 'react-router-dom';
import { ExternalLink, Mail, Phone } from 'lucide-react';
import { PROFILE } from '../data/profile';
import { SERVICES } from '../data/services';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-950 border-t border-slate-900 pt-14 pb-10">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-10 border-b border-slate-900">
          {/* Branding & Contact Summary */}
          <div className="space-y-4">
            <Link to="/" className="inline-flex items-center gap-3 group">
              <div className="w-9 h-9 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center font-bold text-white font-mono shadow-md shadow-cyan-500/20">
                {PROFILE.brandInitials}
              </div>
              <div>
                <div className="font-bold text-white group-hover:text-cyan-400 transition-colors">
                  {PROFILE.name}
                </div>
                <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
                  {PROFILE.shortRole}
                </div>
              </div>
            </Link>
            <p className="text-sm text-slate-400 leading-relaxed">
              {PROFILE.fullTitle}. {PROFILE.locationSummary}
            </p>
            <div className="flex flex-wrap gap-3 pt-1">
              <a
                href={PROFILE.fiverrProfileUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-1.5 bg-slate-900 rounded-full border border-slate-800 text-xs font-bold text-slate-300 hover:border-green-500 hover:text-green-400 transition-colors"
              >
                Fiverr <ExternalLink size={12} />
              </a>
              <a
                href={PROFILE.osdireProfileUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-1.5 bg-slate-900 rounded-full border border-slate-800 text-xs font-bold text-slate-300 hover:border-purple-500 hover:text-purple-400 transition-colors"
              >
                Osdire <ExternalLink size={12} />
              </a>
            </div>
          </div>

          {/* Quick Navigation */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-4">
              Navigation
            </h3>
            <ul className="space-y-2.5 text-sm text-slate-400">
              <li>
                <Link to="/" className="hover:text-cyan-400 transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-cyan-400 transition-colors">
                  About Me
                </Link>
              </li>
              <li>
                <Link to="/technology" className="hover:text-cyan-400 transition-colors">
                  Technology Stack
                </Link>
              </li>
              <li>
                <Link to="/portfolio" className="hover:text-cyan-400 transition-colors">
                  3D Portfolio
                </Link>
              </li>
              <li>
                <Link to="/offers" className="hover:text-cyan-400 transition-colors">
                  Fiverr & Osdire Offers
                </Link>
              </li>
              <li>
                <Link to="/faq" className="hover:text-cyan-400 transition-colors">
                  FAQ
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-cyan-400 transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Services Navigation */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-4">
              Services
            </h3>
            <ul className="space-y-2.5 text-sm text-slate-400">
              <li>
                <Link to="/services" className="hover:text-cyan-400 transition-colors">
                  All Services
                </Link>
              </li>
              {SERVICES.map((service) => (
                <li key={service.slug}>
                  <Link
                    to={`/services/${service.slug}`}
                    className="hover:text-cyan-400 transition-colors"
                  >
                    {service.navLabel}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Direct Contact */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-4">
              Direct Contact
            </h3>
            <div className="space-y-3 text-sm">
              <a
                href={PROFILE.emailHref}
                className="flex items-center gap-2.5 text-slate-300 hover:text-cyan-400 transition-colors"
              >
                <Mail size={16} className="text-cyan-400 shrink-0" />
                <span className="truncate">{PROFILE.email}</span>
              </a>
              <a
                href={PROFILE.phoneHref}
                className="flex items-center gap-2.5 text-slate-300 hover:text-green-400 transition-colors"
              >
                <Phone size={16} className="text-green-400 shrink-0" />
                <span>{PROFILE.phoneDisplay}</span>
              </a>
              <p className="text-xs text-slate-500 pt-2">
                Services starting from {PROFILE.startingPrice}
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Copyright Bar */}
        <div className="pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-slate-800 rounded flex items-center justify-center font-bold text-cyan-500 font-mono text-sm">
              {PROFILE.brandInitials}
            </div>
            <p className="text-slate-500 text-sm">
              © {currentYear} {PROFILE.name}. All rights reserved.
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-slate-400">
            <a href={PROFILE.emailHref} className="hover:text-cyan-400 transition-colors">
              {PROFILE.email}
            </a>
            <span className="text-slate-700" aria-hidden="true">
              |
            </span>
            <a href={PROFILE.phoneHref} className="hover:text-cyan-400 transition-colors">
              {PROFILE.phoneDisplay}
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
