import { useState, type MouseEvent } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Layers } from 'lucide-react';
import type { PortfolioProject } from '../data/projects';
import { useReducedMotion } from '../hooks/useReducedMotion';

interface ProjectCardProps {
  project: PortfolioProject;
  isFocused?: boolean;
}

export default function ProjectCard({
  project,
  isFocused = false,
}: ProjectCardProps) {
  const reducedMotion = useReducedMotion();
  const [tilt, setTilt] = useState({ rotateX: 0, rotateY: 0, active: false });

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    if (reducedMotion) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setTilt({
      rotateX: Number((-y * 7).toFixed(2)),
      rotateY: Number((x * 7).toFixed(2)),
      active: true,
    });
  };

  const handleMouseLeave = () => {
    setTilt({ rotateX: 0, rotateY: 0, active: false });
  };

  return (
    <div
      className="perspective-1000 h-full"
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
    >
      <Link
        to={`/portfolio/${project.slug}`}
        style={{
          transform: reducedMotion
            ? undefined
            : `rotateX(${tilt.rotateX}deg) rotateY(${tilt.rotateY}deg) ${
                tilt.active ? 'translateY(-4px)' : 'translateY(0px)'
              }`,
        }}
        className={`flex flex-col h-full rounded-2xl border p-6 transition-all duration-200 group ${
          isFocused
            ? 'bg-slate-800 border-cyan-500/70 shadow-xl shadow-cyan-500/10'
            : 'bg-slate-800/50 border-slate-700/60 hover:bg-slate-800 hover:border-cyan-500/50'
        }`}
      >
        {/* Visual Preview Header */}
        <div
          className="relative rounded-xl p-5 mb-5 border border-slate-700/70 overflow-hidden"
          style={{
            background: `linear-gradient(135deg, #0f172a 0%, #1e293b 65%, ${project.accentHex}28 100%)`,
          }}
        >
          <div className="flex items-center justify-between gap-2 mb-6">
            <span className="text-xs font-semibold text-cyan-400 uppercase tracking-wider">
              {project.category}
            </span>
            <Layers size={18} className="text-slate-400" />
          </div>
          <div className="text-[11px] font-mono text-amber-300/90 mb-1">
            Editable Demo Placeholder
          </div>
          <h3 className="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors">
            {project.title}
          </h3>
        </div>

        <p className="text-sm text-slate-400 leading-relaxed mb-5 flex-1">
          {project.shortDesc}
        </p>

        <div className="flex flex-wrap gap-2 mb-5">
          {project.technologies.map((tech) => (
            <span
              key={tech}
              className="text-xs px-2 py-1 bg-slate-900 rounded text-slate-400 font-mono border border-slate-800"
            >
              {tech}
            </span>
          ))}
        </div>

        <div className="pt-4 border-t border-slate-700/50 flex items-center justify-between text-xs font-semibold text-cyan-400">
          <span>View Project Blueprint</span>
          <ArrowRight
            size={15}
            className="group-hover:translate-x-1 transition-transform"
          />
        </div>
      </Link>
    </div>
  );
}
