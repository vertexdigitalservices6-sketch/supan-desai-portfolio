import * as THREE from 'three';

export function supportsWebGL(): boolean {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return false;
  }
  try {
    const canvas = document.createElement('canvas');
    const gl =
      canvas.getContext('webgl2') ||
      canvas.getContext('webgl') ||
      canvas.getContext('experimental-webgl');
    if (!gl) return false;
    if ('getExtension' in gl && typeof gl.getExtension === 'function') {
      gl.getExtension('WEBGL_lose_context')?.loseContext();
    }
    return true;
  } catch {
    return false;
  }
}

export function detectSoftwareWebGL(): boolean {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return true;
  }
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) || '');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export function scheduleSoftwareFrame(
  renderer: THREE.WebGLRenderer,
  callback: () => void,
  setTimerId: (id: number) => void
) {
  try {
    const gl = renderer.getContext() as WebGL2RenderingContext;
    if (gl && typeof gl.fenceSync === 'function') {
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        const state = sync ? gl.getSyncParameter(sync, gl.SYNC_STATUS) : gl.SIGNALED;
        if (state === gl.UNSIGNALED) {
          setTimerId(window.setTimeout(poll, 5));
        } else {
          if (sync) gl.deleteSync(sync);
          setTimerId(window.setTimeout(callback, 80));
        }
      };
      setTimerId(window.setTimeout(poll, 5));
      return;
    }
  } catch {
    // Fall back cleanly if fenceSync is unavailable
  }
  setTimerId(window.setTimeout(callback, 80));
}

export function createProjectCardTexture(
  title: string,
  category: string,
  tags: string[],
  accentHex: string,
  secondaryHex: string,
  isSelected: boolean
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 768;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Background gradient matching #0f172a / #1e293b
  const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
  grad.addColorStop(0, '#0f172a');
  grad.addColorStop(0.6, '#1e293b');
  grad.addColorStop(1, '#020617');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Subtle accent glow
  const glow = ctx.createRadialGradient(
    canvas.width * 0.82,
    canvas.height * 0.2,
    20,
    canvas.width * 0.82,
    canvas.height * 0.2,
    340
  );
  glow.addColorStop(0, `${accentHex}44`);
  glow.addColorStop(0.5, `${secondaryHex}18`);
  glow.addColorStop(1, 'rgba(15, 23, 42, 0)');
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Grid blueprint lines
  ctx.strokeStyle = 'rgba(148, 163, 184, 0.08)';
  ctx.lineWidth = 1;
  for (let x = 48; x < canvas.width; x += 48) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, canvas.height);
    ctx.stroke();
  }
  for (let y = 48; y < canvas.height; y += 48) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(canvas.width, y);
    ctx.stroke();
  }

  // Border frame
  ctx.strokeStyle = isSelected ? accentHex : 'rgba(51, 65, 85, 0.9)';
  ctx.lineWidth = isSelected ? 6 : 3;
  ctx.strokeRect(12, 12, canvas.width - 24, canvas.height - 24);

  // Top bar: Category + Demo Placeholder label
  ctx.fillStyle = accentHex;
  ctx.font = 'bold 20px Inter, system-ui, sans-serif';
  ctx.fillText(category.toUpperCase(), 44, 68);

  ctx.fillStyle = '#94a3b8';
  ctx.font = '600 18px "JetBrains Mono", monospace';
  ctx.fillText('EDITABLE DEMO PLACEHOLDER', 44, 102);

  // Title (word-wrapped)
  ctx.fillStyle = '#f8fafc';
  ctx.font = 'bold 42px Inter, system-ui, sans-serif';
  const words = title.split(' ');
  let line = '';
  let y = 195;
  const maxWidth = canvas.width - 88;
  for (const word of words) {
    const testLine = line ? `${line} ${word}` : word;
    if (ctx.measureText(testLine).width > maxWidth && line) {
      ctx.fillText(line, 44, y);
      line = word;
      y += 52;
    } else {
      line = testLine;
    }
  }
  if (line) {
    ctx.fillText(line, 44, y);
  }

  // Accent divider
  ctx.fillStyle = accentHex;
  ctx.fillRect(44, canvas.height - 132, 96, 4);

  // Tech tags along bottom
  ctx.font = '600 20px "JetBrains Mono", monospace';
  let tagX = 44;
  const tagY = canvas.height - 64;
  tags.slice(0, 4).forEach((tag) => {
    const label = tag;
    const width = ctx.measureText(label).width + 28;
    ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
    ctx.fillRect(tagX, tagY - 28, width, 40);
    ctx.strokeStyle = 'rgba(71, 85, 105, 0.9)';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(tagX, tagY - 28, width, 40);
    ctx.fillStyle = '#cbd5e1';
    ctx.fillText(label, tagX + 14, tagY - 1);
    tagX += width + 14;
  });

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}
